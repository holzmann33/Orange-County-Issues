 /*  SAS Data Definition File                        */
 /*  Created by ddltox on Mar 28, 2002  (Thu 02:31 PM PST)  */
 /*  DDL source file: "/u/d7/big/sda_1.2a/tmpdir/AAQxaG.q.txt".  */

/* DDL indicates that dataset record length (reclen) is 120 columns. */

TITLE "ORANGE COUNTY ANNUAL SURVEY 1994";
FILENAME INDATA "    ";      /* Put name of data file between quotes */
LIBNAME LIBRARY "    ";    /* Put directory of data library between quotes */

PROC  FORMAT LIB=LIBRARY;
  VALUE Q1f       1='SINGLE FAMILY' 2='ATTACHED' 3='APARTMENT' 4='MOBILE' 
                  5='OTHER' 9='REFUSE' ;
  VALUE Q2f       1='0-2 YRS' 2='3-5 YRS' 3='6-10 YRS' 4='11-20 YRS' 
                  5='21+ YRS' 9='REFUSE' ;
  VALUE Q3f       1='0-2 YRS' 2='3-5 YRS' 3='6-10 YRS' 4='11-20 YRS' 
                  5='21+ YRS' 9='REFUSE' ;
  VALUE Q4f       1='OWN' 2='RENT' 9='DK, REFUSE' ;
  VALUE Q5f       1='UNDER $500' 2='$501-$750' 3='$751-$1,000' 
                  4='$1,001-$1,500' 5='$1,501+' 9='NA, REFUSE' ;
  VALUE Q6f       1='NOTHING' 2='$1-$500' 3='$501-$750' 4='$751-$1,000' 
                  5='$1,001-$1,500' 6='$1,501-$2,000' 7='$2,001+' 
                  9='NA, REFUSE' ;
  VALUE Q7f       1='BETTER OFF' 2='WORSE OFF' 3='SAME' 9='DK, REFUSE' ;
  VALUE Q8f       1='BETTER OFF' 2='WORSE OFF' 3='SAME' 8='DK' 9='REFUSE' ;
  VALUE Q9f       1='GOOD TIMES' 2='BAD TIMES' 8='DK' 9='REFUSE' ;
  VALUE Q10f      1='GOOD TIMES' 2='DEPRESSION' 8='DK' 9='REFUSE' ;
  VALUE Q11f      1='GOOD TIME' 2='BAD TIME' 8='NEITHER, DK' 9='REFUSE' ;
  VALUE Q12f      1='EXCELLENT' 2='GOOD' 3='FAIR' 4='POOR' 8='DK' 9='REFUSE' ;
  VALUE Q13f      1='MUCH BETTER' 2='SOMEWHAT BETTER' 3='SAME' 
                  4='SOMEWHAT WORSE' 5='MUCH WORSE' 8='DK' 9='REFUSE' ;
  VALUE Q14f      1='EXCELLENT' 2='GOOD' 3='FAIR' 4='POOR' 8='DK' 9='REFUSE' ;
  VALUE Q15f      1='VERY WELL' 2='SOMEWHAT WELL' 3='SOMEWHAT BADLY' 
                  4='VERY BADLY' 9='DK, REFUSE' ;
  VALUE Q16f      1='GROWTH' 2='TRAFFIC' 3='HOUSING' 4='CRIME' 5='SCHOOLS' 
                  6='IMMIGRATION' 7='ECONOMY' 8='OTHER' 9='DK, REFUSE' ;
  VALUE Q17f      1='HEALTH CARE' 2='CHILD CARE' 3='RACE RELATIONS' 
                  4='HOMELESS' 5='DRUG ABUSE' 6='AIDS' 7='OTHER' 
                  9='DK, REFUSE' ;
  VALUE Q18f      1='BETTER PLACE' 2='WORSE PLACE' 3='NO CHANGE' 
                  9='DK, REFUSE' ;
  VALUE Q19f      1='BIG PROBLEM' 2='SOME PROBLEM' 3='SMALL PROBLEM' 
                  4='NO PROBLEM' 8='DK' 9='REFUSE' ;
  VALUE Q20f      1='VERY OFTEN' 2='SOMETIMES' 3='RARELY' 4='NEVER' 8='DK' 
                  9='REFUSE' ;
  VALUE Q21f      1='VERY OFTEN' 2='SOMETIMES' 3='RARELY' 4='NEVER' 8='DK' 
                  9='REFUSE' ;
  VALUE Q22f      1='VERY OFTEN' 2='SOMETIMES' 3='RARELY' 4='NEVER' 8='DK' 
                  9='REFUSE' ;
  VALUE Q23f      1='VERY FEARFUL' 2='SOMEWHAT FEARFUL' 3='NOT TOO FEARFUL' 
                  4='NOT FEARFUL' 8='DK' 9='REFUSE' ;
  VALUE Q24f      1='GREAT DEAL' 2='SOME' 3='NOT MUCH' 4='NONE' 8='DK' 
                  9='REFUSE' ;
  VALUE Q25f      1='GREAT DEAL' 2='SOME' 3='NOT MUCH' 4='NONE' 8='DK' 
                  9='REFUSE' ;
  VALUE Q26f      1='GREAT DEAL' 2='QUITE A BIT' 3='NOT VERY MUCH' 4='NONE' 
                  8='DK' 9='REFUSE' ;
  VALUE Q27f      1='GREAT DEAL' 2='QUITE A BIT' 3='NOT VERY MUCH' 4='NONE' 
                  8='DK' 9='REFUSE' ;
  VALUE Q28f      1='STRONGLY FAVOR' 2='SOMEWHAT FAVOR' 3='SOMEWHAT OPPOSE' 
                  4='STRONGLY OPPOSE' 8='DK' 9='REFUSE' ;
  VALUE Q29f      1='GROWING RAPIDLY' 2='GROWING SLOWLY' 3='STAYING SAME' 
                  4='LOSING POP' 8='DK' 9='REFUSE' ;
  VALUE Q30f      1='TOO STRICT' 2='ABOUT RIGHT' 3='NOT STRICT ENOUGH' 
                  9='DK,REFUSE' ;
  VALUE Q31f      1='SATISFACTORY' 2='MORE LANES ONLY' 3='NEW FREEWAYS' 
                  9='DK, REFUSE' ;
  VALUE Q32f      1='FULL-TIME' 2='PART-TIME' 3='NOT EMPLOYED' 9='REFUSE' ;
  VALUE Q33f      1='DRIVE ALONE' 2='CARPOOL' 3='VANPOOL' 4='PUBLIC TRANSIT' 
                  5='OTHER' 9='DK, REFUSE' ;
  VALUE Q34f      1='NO PROBLEM' 2='SOME PROBLEM' 3='GREAT PROBLEM' 9='NA' ;
  VALUE Q35f      1='VERY SERIOUS' 2='SOMEWHAT SERIOUS' 3='NOT TOO SERIOUS' 
                  8='DK' 9='REFUSE' ;
  VALUE Q36f      1='STRONGLY AGREE' 2='SOMEWHAT AGREE' 3='SOMEWHAT DISAGREE' 
                  4='STRONGLY DISAGREE' 8='DK' 9='REFUSE' ;
  VALUE Q37f      1='STRONGLY AGREE' 2='SOMEWHAT AGREE' 3='SOMEWHAT DISAGREE' 
                  4='STRONGLY DISAGREE' 8='DK' 9='REFUSE' ;
  VALUE Q38f      1='STRONGLY AGREE' 2='SOMEWHAT AGREE' 3='SOMEWHAT DISAGREE' 
                  4='STRONGLY DISAGREE' 8='DK' 9='REFUSE' ;
  VALUE Q39f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q40f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q41f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q42f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q43f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q44f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q45f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q46f      1='VERY SERIOUS' 2='SOMEWHAT SERIOUS' 3='NOT SERIOUS' 
                  8='DK' 9='REFUSE' ;
  VALUE Q47f      1='IN CONFLICT' 2='GETTING ALONG' 8='DK' 9='REFUSE' ;
  VALUE Q48f      1='IMPROVE A LOT' 2='IMPROVE SOMEWHAT' 3='STAY SAME' 
                  4='GET SOMEWHAT WORSE' 5='GET A LOT WORSE' 8='DK' 
                  9='REFUSE' ;
  VALUE Q49f      1='HELPED' 2='HURT' 8='DK' 9='REFUSE' ;
  VALUE Q50f      1='EASIER' 2='HARDER' 8='DK' 9='REFUSE' ;
  VALUE Q51f      1='HELPED' 2='HURT' 8='DK' 9='REFUSE' ;
  VALUE Q52f      1='ALWAYS' 2='FREQUENTLY' 3='OCCASIONALLY' 4='SELDOM' 
                  5='NEVER' 8='DK' 9='REFUSE' ;
  VALUE Q53f      1='ALWAYS' 2='FREQUENTLY' 3='OCCASIONALLY' 4='SELDOM' 
                  5='NEVER' 8='DK' 9='REFUSE' ;
  VALUE Q54f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q55f      1='GOOD' 2='BAD' 8='DK' 9='REFUSE' ;
  VALUE Q56f      1='VERY UNEASY' 2='SOMEWHAT UNEASY' 3='NEITHER' 
                  4='SOMEWHAT RELAXED' 5='VERY RELAXED' 8='DK' 9='REFUSE' ;
  VALUE Q57f      1='VERY OFTEN' 2='SOMEWHAT OFTEN' 3='NOW AND THEN' 
                  4='RARELY' 5='NEVER' 8='DK' 9='REFUSE' ;
  VALUE Q58f      1='JUST AN AMERICAN' 2='SPEC ETHNIC GP' 3='2+ ETHNIC GPS' 
                  4='AM &  ETHNIC GP' 5='DEPENDS' 8='DK' 9='REFUSE' ;
  VALUE Q59f      1='1 DISTINCT CULTURES' 2='2' 3='3' 4='4' 5='5' 6='6' 
                  7='7 BLEND IN' 8='DK' 9='REFUSE' ;
  VALUE Q60f      1='TOO MUCH' 2='TOO LITTLE' 3='ABOUT RIGHT' 8='DK' 
                  9='REFUSE' ;
  VALUE Q61f      1='A LOT' 2='SOMEWHAT' 3='VERY LITTLE' 4='NOT AT ALL' 
                  8='DK' 9='REFUSE' ;
  VALUE Q62f      1='A LOT' 2='SOMEWHAT' 3='VERY LITTLE' 4='NOT AT ALL' 
                  8='DK' 9='REFUSE' ;
  VALUE Q63f      1='VERY IMPT' 2='SOMEWHAT IMPT' 3='SOMEWHAT UNIMPT' 
                  4='VERY UNIMPT' 8='DK' 9='REFUSE' ;
  VALUE Q64f      1='VERY IMPT' 2='SOMEWHAT IMPT' 3='SOMEWHAT UNIMPT' 
                  4='VERY UNIMPT' 8='DK' 9='REFUSE' ;
  VALUE Q65f      1='GOVT' 2='INDIVIDUALS' 3='SCHOOLS' 4='NONPROFIT ORGS' 
                  5='CHURCHES' 6='BUSINESSES' 7='OTHER' 8='DK' 9='REFUSE' ;
  VALUE Q66f      1='ESSENTIAL' 2='VERY IMPT' 3='SOMEWHAT IMPT' 
                  4='NOT VERY IMPT' 5='NOT AT ALL IMPT' 8='DK' 9='REFUSE' ;
  VALUE Q67f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q68f      1='ONE' 2='MORE THAN ONE' 8='DK' 9='REFUSE' ;
  VALUE Q69f      1='NO TIME' 2='LESS THAN 1 HR' 3='1 HR' 4='2-4 HRS' 
                  5='5+ HRS' 8='DK' 9='REFUSE' ;
  VALUE Q70f      1='ASKED BY SOMEONE' 2='FAM MEMB IN ORG' 3='THROUGH ORG' 
                  4='SAW AD' 5='ON OWN' 6='VOLUNTEER CENTER' 7='OTHER' 8='DK' 
                  9='REFUSE' ;
  VALUE Q71f      1='TOO BUSY' 2='UNABLE TO HONOR' 3='NOT INTERESTED' 
                  4='DONT KNOW HOW' 5='NO ONE ASKED' 6='WOULDNT MAKE DIFF' 
                  7='OTHER' 8='DK' 9='REFUSE' ;
  VALUE Q72f      1='ENJOY WORK' 2='FEEL NEEDED' 3='IMPORTANT TO HELP' 
                  4='FAM IN ACTIVITY' 5='LEARN NEW SKILLS' 6='MAKE CONTACTS' 
                  7='OTHER' 8='DK' 9='REFUSE' ;
  VALUE Q73f      1='BIG DIFF' 2='SOME DIFF' 3='SMALL DIFF' 4='NO DIFF' 
                  8='DK' 9='REFUSE' ;
  VALUE Q74f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q75f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q76f      1='NOTHING' 2='$1-$100' 3='$101-$250' 4='$251-$500' 
                  5='$501-$999' 6='$1000+' 9='DK, REFUSE' ;
  VALUE Q77f      1='18-34' 2='35-54' 3='55+' 9='REFUSE' ;
  VALUE Q78f      1='< H.S.' 2='H.S. GRAD' 3='SOME COLLEGE' 4='COLLEGE GRAD' 
                  5='POST GRAD' 9='REFUSE' ;
  VALUE Q79f      0='NONE' 1='ONE' 2='TWO' 3='THREE OR MORE' 9='REFUSE' ;
  VALUE Q80f      1='NORTH' 2='WEST' 3='CENTRAL' 4='SOUTH' 5='OUTSIDE OC' 
                  9='NO ANS' ;
  VALUE Q81f      1='UNDER $36,000' 2='$36,000-$50,000' 3='$50,001-$79,999' 
                  4='$80,000+' 9='DK, REFUSE' ;
  VALUE Q82f      1='VERY LIBERAL' 2='SOMEWHAT LIBERAL' 3='MIDDLE OF ROAD' 
                  4='SOMEWHAT CONSERV' 5='VERY CONSERV' 9='REFUSE' ;
  VALUE Q83f      1='DEMOCRAT' 2='REPUBLICAN' 3='INDEP/OTHER' 
                  4='NOT REGISTERED' 9='REFUSE' ;
  VALUE Q84f      1='WILSON' 2='BROWN' 3='OTHER' 8='DK' 9='REFUSE' ;
  VALUE Q85f      1='HUFFINGTON' 2='FEINSTEIN' 3='OTHER' 8='DK' 9='REFUSE' ;
  VALUE Q86f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q87f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q88f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q89f      1='STRONGLY AGREE' 2='SOMEWHAT AGREE' 3='SOMEWHAT DISAGREE' 
                  4='STRONGLY DISAGREE' 8='DK' 9='REFUSE' ;
  VALUE Q90f      1='STRONGLY AGREE' 2='SOMEWHAT AGREE' 3='SOMEWHAT DISAGREE' 
                  4='STRONGLY DISAGREE' 8='DK' 9='REFUSE' ;
  VALUE Q91f      1='STRONGLY AGREE' 2='SOMEWHAT AGREE' 3='SOMEWHAT DISAGREE' 
                  4='STRONGLY DISAGREE' 8='DK' 9='REFUSE' ;
  VALUE Q92f      0='NEVER' 1='1X' 2='2X' 3='3X' 4='4X+' 8='DK' 9='REFUSE' ;
  VALUE Q93f      1='ASIAN' 2='BLACK' 3='HISPANIC' 4='CAUCASIAN' 5='OTHER' 
                  9='REFUSE' ;
  VALUE Q94f      1='MALE' 2='FEMALE' ;
  VALUE LANG      1='ENGLISH' 2='SPANISH' ;
  VALUE YEAR      1994='YEAR OF SURVEY' ;
RUN;

DATA IN (LABEL="ORANGE COUNTY ANNUAL SURVEY 1994");
  INFILE INDATA LRECL=120;
  INPUT
    #1  CASEID 1-4              Q1 5                    Q2 6                    
        Q3 7                    Q4 8                    Q5 9                    
        Q6 10                   Q7 11                   Q8 12                   
        Q9 13                   Q10 14                  Q11 15                  
        Q12 16                  Q13 17                  Q14 18                  
        Q15 19                  Q16 20                  Q17 21                  
        Q18 22                  Q19 23                  Q20 24                  
        Q21 25                  Q22 26                  Q23 27                  
        Q24 28                  Q25 29                  Q26 30                  
        Q27 31                  Q28 32                  Q29 33                  
        Q30 34                  Q31 35                  Q32 36                  
        Q33 37                  Q34 38                  Q35 39                  
        Q36 40                  Q37 41                  Q38 42                  
        Q39 43                  Q40 44                  Q41 45                  
        Q42 46                  Q43 47                  Q44 48                  
        Q45 49                  Q46 50                  Q47 51                  
        Q48 52                  Q49 53                  Q50 54                  
        Q51 55                  Q52 56                  Q53 57                  
        Q54 58                  Q55 59                  Q56 60                  
        Q57 61                  Q58 62                  Q59 63                  
        Q60 64                  Q61 65                  Q62 66                  
        Q63 67                  Q64 68                  Q65 69                  
        Q66 70                  Q67 71                  Q68 72                  
        Q69 73                  Q70 74                  Q71 75                  
        Q72 76                  Q73 77                  Q74 78                  
        Q75 79                  Q76 80                  Q77 81                  
        Q78 82                  Q79 83                  Q80 84-85               
        Q81 86                  Q82 87                  Q83 88                  
        Q84 89                  Q85 90                  Q86 91                  
        Q87 92                  Q88 93                  Q89 94                  
        Q90 95                  Q91 96                  Q92 97                  
        Q93 98                  Q94 99                  LANG 100                
        WEIGHT 101-108 .2       WT 109-116 .2           YEAR 117-120            
        ;

  LABEL
   CASEID  = 'CASE ID'
   Q1      = 'TYPE OF CURRENT RESIDENCE'
   Q2      = 'HOW LONG LIVE IN OC'
   Q3      = 'HOW LONG LIVE AT CURRENT RESIDENCE'
   Q4      = 'OWN/RENT PRESENT RESIDENCE'
   Q5      = 'MONTHLY RENTAL PAYMENT'
   Q6      = 'MONTHLY MORTGAGE PAYMENT'
   Q7      = 'BETTER OFF/WORSE OFF/SAME LAST YEAR'
   Q8      = 'BETTER OFF/WORSE OFF/SAME NEXT YEAR'
   Q9      = 'NAT''L BUSINESS CONDS NEXT 12 MO'
   Q10     = 'NAT''L CONDS NEXT 5 YEARS'
   Q11     = 'GD/BAD TIME TO BUY MAJ HSEHOLD ITEMS'
   Q12     = 'RATE ECONOMY IN OC TODAY'
   Q13     = 'OC ECONOMY 2 YRS FROM NOW'
   Q14     = 'BUYING OC HOME GOOD INVESTMENT TODAY'
   Q15     = 'QUALITY OF LIFE IN OC'
   Q16     = 'MOST SERIOUS PUBLIC POLICY PROBLEM'
   Q17     = 'MOST SERIOUS SOCIAL PROBLEM'
   Q18     = 'OC IN FUTURE'
   Q19     = 'CRIME A PROBLEM IN OC'
   Q20     = 'CRIME FEAR KEEPS YOU FROM SHOPPING'
   Q21     = 'CRIME FEAR KEEPS YOU FROM PARKS'
   Q22     = 'CRIME FEAR KEEPS YOU FROM MOVIES'
   Q23     = 'FEARFUL THAT WILL BE CRIME VICTIM'
   Q24     = 'ATTENTION TO CRIME NEWS IN NEWSPAPERS'
   Q25     = 'ATTENTION TO CRIME NEWS ON TV'
   Q26     = 'CONFIDENCE IN POLICE'
   Q27     = 'CONFIDENCE IN COURTS'
   Q28     = 'TOUGHER GUN CONTROL LAWS'
   Q29     = 'POP GROWTH IN CITY PAST FEW YRS'
   Q30     = 'CURRENT GROWTH REGS IN CITY'
   Q31     = 'FEELING ABOUT FREEWAYS IN OC'
   Q32     = 'WORK STATUS'
   Q33     = 'HOW COMMUTE TO WORK'
   Q34     = 'TRAFFIC CONGESTION DURING COMMUTE'
   Q35     = 'HOW SERIOUS A THREAT ARE ENV PROBS'
   Q36     = 'STORM DRAINS AND SEWERS ON SAME SYSTEM'
   Q37     = 'STORM DRAIN WATER IS TREATED'
   Q38     = 'ILLEGAL TO THROW THINGS IN STORM DRAINS'
   Q39     = 'SEEN ANNOUNCEMENTS ABOUT DUMPING'
   Q40     = 'SEEN ''OCEAN BEGINS...'' BROCHURE'
   Q41     = 'SEEN STENCILLING ON CURBS'
   Q42     = 'SANTA ANA RIVER IS FLOOD THREAT'
   Q43     = 'YR RESIDENCE IN A FLOOD PLAIN'
   Q44     = 'SEEN ANNOUNCEMENTS ABOUT FLOODING'
   Q45     = 'SEEN FLOOD AWARENESS BROCHURES'
   Q46     = 'MINORITIES HAVE PROBLEMS LIVING HERE'
   Q47     = 'ETHNIC RELATIONS IN OC'
   Q48     = 'RELATIONS NEXT 10 YRS'
   Q49     = 'ETHNIC VARIETY IMPACT ON QUALITY OF LIFE'
   Q50     = 'ETHNIC VARIETY IMPACT ON LOCAL GOVT'
   Q51     = 'ETHNIC VARIETY IMPACT ON LOCAL ECONOMY'
   Q52     = 'EXPERIENCE ETHNIC DISCRIMINATION'
   Q53     = 'OTHERS IN ETHNIC GP EXPERIENCE DISCRIMIN'
   Q54     = 'MAKEUP OF NEIGHBORHOOD CHANGING'
   Q55     = 'CHANGE GOOD/BAD FOR NBHD'
   Q56     = 'HOW FEEL W/ PEOPLE FROM DIFF ETHNIC GPS'
   Q57     = 'FELT PRESSURE NOT TO SOCIALIZE W/ OTHER'
   Q58     = 'YOUR ETHNIC IDENTITY'
   Q59     = 'VIEWS ON MELTING POT'
   Q60     = 'ATTENTION GIVEN TO MINORITIES IN HISTORY'
   Q61     = 'PROGRAMS TO INCREASE DIALOGUE'
   Q62     = 'PROGRAMS TO RAISE PUBLIC UNDERSTANDING'
   Q63     = 'HOW IMPT EFFORTS TO OC ECONOMY'
   Q64     = 'HOW IMPT EFFORTS TO OC QUALITY OF LIFE'
   Q65     = 'RESPONSIBILITY FOR IMPROVING RELATIONS'
   Q66     = 'HOW IMPT VOLUNTEER WORK'
   Q67     = 'VOLUNTEERED IN PAST 12 MO'
   Q68     = 'HOW MANY ORGS VOLUNTEERED FOR'
   Q69     = 'HOURS SPENT VOLUNTEERING IN PAST MO'
   Q70     = 'HOW LEARNED ABOUT VOL ACTIVITIES'
   Q71     = 'WHY NOT A VOLUNTEER'
   Q72     = 'MOST IMPT REASON FOR VOLUNTEERING'
   Q73     = 'VOLUNTEER''S IMPACT ON COMMUNITY PROBLEMS'
   Q74     = 'VOLUNTEER INFO ORG HELPFUL'
   Q75     = 'HEARD ABOUT VOLUNTEER CENTER'
   Q76     = '$ GAVE TO ALL CHARITIES LAST YR'
   Q77     = 'AGE'
   Q78     = 'EDUCATION'
   Q79     = 'NUMBER OF CHILDREN IN HHOLD'
   Q80     = 'RESIDENCE'
   Q81     = 'ANNUAL HOUSEHOLD INCOME'
   Q82     = 'CONSIDER YOURSELF POLITICALLY:'
   Q83     = 'PARTY'
   Q84     = 'VOTE FOR GOVERNOR'
   Q85     = 'VOTE FOR U.S. SENATOR'
   Q86     = 'VOTE ON PROP 184 (THREE STRIKES)'
   Q87     = 'VOTE ON PROP 187 (SAVE OUR STATE)'
   Q88     = 'VOTE ON MEASURE R (EL TORO AIRPORT)'
   Q89     = 'EL TORO AIRPORT WD CREATE JOBS'
   Q90     = 'EL TORO AIRPORT WD BE TOO NOISY'
   Q91     = 'AIRPORT MOST FISCALLY SOUND OPTION'
   Q92     = 'VOTED IN PAST 4 YRS'
   Q93     = 'RACE'
   Q94     = 'SEX'
   LANG    = 'LANGUAGE OF INTERVIEW'
   WEIGHT  = 'WEIGHT'
   WT      = 'WT'
   YEAR    = 'YEAR OF SURVEY'  ;
  FORMAT Q1 Q1f. Q2 Q2f. Q3 Q3f. 
         Q4 Q4f. Q5 Q5f. Q6 Q6f. 
         Q7 Q7f. Q8 Q8f. Q9 Q9f. 
         Q10 Q10f. Q11 Q11f. Q12 Q12f. 
         Q13 Q13f. Q14 Q14f. Q15 Q15f. 
         Q16 Q16f. Q17 Q17f. Q18 Q18f. 
         Q19 Q19f. Q20 Q20f. Q21 Q21f. 
         Q22 Q22f. Q23 Q23f. Q24 Q24f. 
         Q25 Q25f. Q26 Q26f. Q27 Q27f. 
         Q28 Q28f. Q29 Q29f. Q30 Q30f. 
         Q31 Q31f. Q32 Q32f. Q33 Q33f. 
         Q34 Q34f. Q35 Q35f. Q36 Q36f. 
         Q37 Q37f. Q38 Q38f. Q39 Q39f. 
         Q40 Q40f. Q41 Q41f. Q42 Q42f. 
         Q43 Q43f. Q44 Q44f. Q45 Q45f. 
         Q46 Q46f. Q47 Q47f. Q48 Q48f. 
         Q49 Q49f. Q50 Q50f. Q51 Q51f. 
         Q52 Q52f. Q53 Q53f. Q54 Q54f. 
         Q55 Q55f. Q56 Q56f. Q57 Q57f. 
         Q58 Q58f. Q59 Q59f. Q60 Q60f. 
         Q61 Q61f. Q62 Q62f. Q63 Q63f. 
         Q64 Q64f. Q65 Q65f. Q66 Q66f. 
         Q67 Q67f. Q68 Q68f. Q69 Q69f. 
         Q70 Q70f. Q71 Q71f. Q72 Q72f. 
         Q73 Q73f. Q74 Q74f. Q75 Q75f. 
         Q76 Q76f. Q77 Q77f. Q78 Q78f. 
         Q79 Q79f. Q80 Q80f. Q81 Q81f. 
         Q82 Q82f. Q83 Q83f. Q84 Q84f. 
         Q85 Q85f. Q86 Q86f. Q87 Q87f. 
         Q88 Q88f. Q89 Q89f. Q90 Q90f. 
         Q91 Q91f. Q92 Q92f. Q93 Q93f. 
         Q94 Q94f. LANG LANG. YEAR YEAR. 
          ;

/* md, min and max specifications were translated  */
/* into the following "IF" statements:           */

IF (Q1 = 9) THEN Q1 = .;
IF (Q2 = 9) THEN Q2 = .;
IF (Q3 = 9) THEN Q3 = .;
IF (Q4 = 9) THEN Q4 = .;
IF (Q5 = 9) THEN Q5 = .;
IF (Q6 = 9) THEN Q6 = .;
IF (Q7 = 9) THEN Q7 = .;
IF (Q8 = 9) THEN Q8 = .;
IF (Q9 = 9) THEN Q9 = .;
IF (Q10 = 9) THEN Q10 = .;
IF (Q11 = 9) THEN Q11 = .;
IF (Q12 = 9) THEN Q12 = .;
IF (Q13 = 9) THEN Q13 = .;
IF (Q14 = 9) THEN Q14 = .;
IF (Q15 = 9) THEN Q15 = .;
IF (Q16 = 9) THEN Q16 = .;
IF (Q17 = 9) THEN Q17 = .;
IF (Q18 = 9) THEN Q18 = .;
IF (Q19 = 9) THEN Q19 = .;
IF (Q20 = 9) THEN Q20 = .;
IF (Q21 = 9) THEN Q21 = .;
IF (Q22 = 9) THEN Q22 = .;
IF (Q23 = 9) THEN Q23 = .;
IF (Q24 = 9) THEN Q24 = .;
IF (Q25 = 9) THEN Q25 = .;
IF (Q26 = 9) THEN Q26 = .;
IF (Q27 = 9) THEN Q27 = .;
IF (Q28 = 9) THEN Q28 = .;
IF (Q29 = 9) THEN Q29 = .;
IF (Q30 = 9) THEN Q30 = .;
IF (Q31 = 9) THEN Q31 = .;
IF (Q32 = 9) THEN Q32 = .;
IF (Q33 = 9) THEN Q33 = .;
IF (Q34 = 9) THEN Q34 = .;
IF (Q35 = 9) THEN Q35 = .;
IF (Q36 = 9) THEN Q36 = .;
IF (Q37 = 9) THEN Q37 = .;
IF (Q38 = 9) THEN Q38 = .;
IF (Q39 = 9) THEN Q39 = .;
IF (Q40 = 9) THEN Q40 = .;
IF (Q41 = 9) THEN Q41 = .;
IF (Q42 = 9) THEN Q42 = .;
IF (Q43 = 9) THEN Q43 = .;
IF (Q44 = 9) THEN Q44 = .;
IF (Q45 = 9) THEN Q45 = .;
IF (Q46 = 9) THEN Q46 = .;
IF (Q47 = 9) THEN Q47 = .;
IF (Q48 = 9) THEN Q48 = .;
IF (Q49 = 9) THEN Q49 = .;
IF (Q50 = 9) THEN Q50 = .;
IF (Q51 = 9) THEN Q51 = .;
IF (Q52 = 9) THEN Q52 = .;
IF (Q53 = 9) THEN Q53 = .;
IF (Q54 = 9) THEN Q54 = .;
IF (Q55 = 9) THEN Q55 = .;
IF (Q56 = 9) THEN Q56 = .;
IF (Q57 = 9) THEN Q57 = .;
IF (Q58 = 9) THEN Q58 = .;
IF (Q59 = 9) THEN Q59 = .;
IF (Q60 = 9) THEN Q60 = .;
IF (Q61 = 9) THEN Q61 = .;
IF (Q62 = 9) THEN Q62 = .;
IF (Q63 = 9) THEN Q63 = .;
IF (Q64 = 9) THEN Q64 = .;
IF (Q65 = 9) THEN Q65 = .;
IF (Q66 = 9) THEN Q66 = .;
IF (Q67 = 9) THEN Q67 = .;
IF (Q68 = 9) THEN Q68 = .;
IF (Q69 = 9) THEN Q69 = .;
IF (Q70 = 9) THEN Q70 = .;
IF (Q71 = 9) THEN Q71 = .;
IF (Q72 = 9) THEN Q72 = .;
IF (Q73 = 9) THEN Q73 = .;
IF (Q74 = 9) THEN Q74 = .;
IF (Q75 = 9) THEN Q75 = .;
IF (Q76 = 9) THEN Q76 = .;
IF (Q77 = 9) THEN Q77 = .;
IF (Q78 = 9) THEN Q78 = .;
IF (Q79 = 9) THEN Q79 = .;
IF (Q81 = 9) THEN Q81 = .;
IF (Q82 = 9) THEN Q82 = .;
IF (Q83 = 9) THEN Q83 = .;
IF (Q84 = 9) THEN Q84 = .;
IF (Q85 = 9) THEN Q85 = .;
IF (Q86 = 9) THEN Q86 = .;
IF (Q87 = 9) THEN Q87 = .;
IF (Q88 = 9) THEN Q88 = .;
IF (Q89 = 9) THEN Q89 = .;
IF (Q90 = 9) THEN Q90 = .;
IF (Q91 = 9) THEN Q91 = .;
IF (Q92 = 9) THEN Q92 = .;
IF (Q93 = 9) THEN Q93 = .;

PROC DATASETS;
  CONTENTS DATA=IN POSITION;
  TITLE 'CONTENTS OF ALL VARIABLES';
RUN;
