path        = ocas94/
title       = ORANGE COUNTY ANNUAL SURVEY 1994
records/case= 1
reclen      = 120
*
name        = CASEID
label       = CASE ID
type        = numeric
record      = 1
column      = 1
width       = 4
*
name        = Q1
label       = TYPE OF CURRENT RESIDENCE
type        = numeric
record      = 1
column      = 5
width       = 1
md          = 9
catlabels   = 1 SINGLE FAMILY
              2 ATTACHED
              3 APARTMENT
              4 MOBILE
              5 OTHER
              9 REFUSE
*
name        = Q2
label       = HOW LONG LIVE IN OC
type        = numeric
record      = 1
column      = 6
width       = 1
md          = 9
catlabels   = 1 0-2 YRS
              2 3-5 YRS
              3 6-10 YRS
              4 11-20 YRS
              5 21+ YRS
              9 REFUSE
*
name        = Q3
label       = HOW LONG LIVE AT CURRENT RESIDENCE
type        = numeric
record      = 1
column      = 7
width       = 1
md          = 9
catlabels   = 1 0-2 YRS
              2 3-5 YRS
              3 6-10 YRS
              4 11-20 YRS
              5 21+ YRS
              9 REFUSE
*
name        = Q4
label       = OWN/RENT PRESENT RESIDENCE
type        = numeric
record      = 1
column      = 8
width       = 1
md          = 9
catlabels   = 1 OWN
              2 RENT
              9 DK, REFUSE
*
name        = Q5
label       = MONTHLY RENTAL PAYMENT
type        = numeric
record      = 1
column      = 9
width       = 1
md          = 9
catlabels   = 1 UNDER $500
              2 $501-$750
              3 $751-$1,000
              4 $1,001-$1,500
              5 $1,501+
              9 NA, REFUSE
*
name        = Q6
label       = MONTHLY MORTGAGE PAYMENT
type        = numeric
record      = 1
column      = 10
width       = 1
md          = 9
catlabels   = 1 NOTHING
              2 $1-$500
              3 $501-$750
              4 $751-$1,000
              5 $1,001-$1,500
              6 $1,501-$2,000
              7 $2,001+
              9 NA, REFUSE
*
name        = Q7
label       = BETTER OFF/WORSE OFF/SAME LAST YEAR
type        = numeric
record      = 1
column      = 11
width       = 1
md          = 9
catlabels   = 1 BETTER OFF
              2 WORSE OFF
              3 SAME
              9 DK, REFUSE
*
name        = Q8
label       = BETTER OFF/WORSE OFF/SAME NEXT YEAR
type        = numeric
record      = 1
column      = 12
width       = 1
md          = 9
catlabels   = 1 BETTER OFF
              2 WORSE OFF
              3 SAME
              8 DK
              9 REFUSE
*
name        = Q9
label       = NAT'L BUSINESS CONDS NEXT 12 MO
type        = numeric
record      = 1
column      = 13
width       = 1
md          = 9
catlabels   = 1 GOOD TIMES
              2 BAD TIMES
              8 DK
              9 REFUSE
*
name        = Q10
label       = NAT'L CONDS NEXT 5 YEARS
type        = numeric
record      = 1
column      = 14
width       = 1
md          = 9
catlabels   = 1 GOOD TIMES
              2 DEPRESSION
              8 DK
              9 REFUSE
*
name        = Q11
label       = GD/BAD TIME TO BUY MAJ HSEHOLD ITEMS
type        = numeric
record      = 1
column      = 15
width       = 1
md          = 9
catlabels   = 1 GOOD TIME
              2 BAD TIME
              8 NEITHER, DK
              9 REFUSE
*
name        = Q12
label       = RATE ECONOMY IN OC TODAY
type        = numeric
record      = 1
column      = 16
width       = 1
md          = 9
catlabels   = 1 EXCELLENT
              2 GOOD
              3 FAIR
              4 POOR
              8 DK
              9 REFUSE
*
name        = Q13
label       = OC ECONOMY 2 YRS FROM NOW
type        = numeric
record      = 1
column      = 17
width       = 1
md          = 9
catlabels   = 1 MUCH BETTER
              2 SOMEWHAT BETTER
              3 SAME
              4 SOMEWHAT WORSE
              5 MUCH WORSE
              8 DK
              9 REFUSE
*
name        = Q14
label       = BUYING OC HOME GOOD INVESTMENT TODAY
type        = numeric
record      = 1
column      = 18
width       = 1
md          = 9
catlabels   = 1 EXCELLENT
              2 GOOD
              3 FAIR
              4 POOR
              8 DK
              9 REFUSE
*
name        = Q15
label       = QUALITY OF LIFE IN OC
type        = numeric
record      = 1
column      = 19
width       = 1
md          = 9
catlabels   = 1 VERY WELL
              2 SOMEWHAT WELL
              3 SOMEWHAT BADLY
              4 VERY BADLY
              9 DK, REFUSE
*
name        = Q16
label       = MOST SERIOUS PUBLIC POLICY PROBLEM
type        = numeric
record      = 1
column      = 20
width       = 1
md          = 9
catlabels   = 1 GROWTH
              2 TRAFFIC
              3 HOUSING
              4 CRIME
              5 SCHOOLS
              6 IMMIGRATION
              7 ECONOMY
              8 OTHER
              9 DK, REFUSE
*
name        = Q17
label       = MOST SERIOUS SOCIAL PROBLEM
type        = numeric
record      = 1
column      = 21
width       = 1
md          = 9
catlabels   = 1 HEALTH CARE
              2 CHILD CARE
              3 RACE RELATIONS
              4 HOMELESS
              5 DRUG ABUSE
              6 AIDS
              7 OTHER
              9 DK, REFUSE
*
name        = Q18
label       = OC IN FUTURE
type        = numeric
record      = 1
column      = 22
width       = 1
md          = 9
catlabels   = 1 BETTER PLACE
              2 WORSE PLACE
              3 NO CHANGE
              9 DK, REFUSE
*
name        = Q19
label       = CRIME A PROBLEM IN OC
type        = numeric
record      = 1
column      = 23
width       = 1
md          = 9
catlabels   = 1 BIG PROBLEM
              2 SOME PROBLEM
              3 SMALL PROBLEM
              4 NO PROBLEM
              8 DK
              9 REFUSE
*
name        = Q20
label       = CRIME FEAR KEEPS YOU FROM SHOPPING
type        = numeric
record      = 1
column      = 24
width       = 1
md          = 9
catlabels   = 1 VERY OFTEN
              2 SOMETIMES
              3 RARELY
              4 NEVER
              8 DK
              9 REFUSE
*
name        = Q21
label       = CRIME FEAR KEEPS YOU FROM PARKS
type        = numeric
record      = 1
column      = 25
width       = 1
md          = 9
catlabels   = 1 VERY OFTEN
              2 SOMETIMES
              3 RARELY
              4 NEVER
              8 DK
              9 REFUSE
*
name        = Q22
label       = CRIME FEAR KEEPS YOU FROM MOVIES
type        = numeric
record      = 1
column      = 26
width       = 1
md          = 9
catlabels   = 1 VERY OFTEN
              2 SOMETIMES
              3 RARELY
              4 NEVER
              8 DK
              9 REFUSE
*
name        = Q23
label       = FEARFUL THAT WILL BE CRIME VICTIM
type        = numeric
record      = 1
column      = 27
width       = 1
md          = 9
catlabels   = 1 VERY FEARFUL
              2 SOMEWHAT FEARFUL
              3 NOT TOO FEARFUL
              4 NOT FEARFUL
              8 DK
              9 REFUSE
*
name        = Q24
label       = ATTENTION TO CRIME NEWS IN NEWSPAPERS
type        = numeric
record      = 1
column      = 28
width       = 1
md          = 9
catlabels   = 1 GREAT DEAL
              2 SOME
              3 NOT MUCH
              4 NONE
              8 DK
              9 REFUSE
*
name        = Q25
label       = ATTENTION TO CRIME NEWS ON TV
type        = numeric
record      = 1
column      = 29
width       = 1
md          = 9
catlabels   = 1 GREAT DEAL
              2 SOME
              3 NOT MUCH
              4 NONE
              8 DK
              9 REFUSE
*
name        = Q26
label       = CONFIDENCE IN POLICE
type        = numeric
record      = 1
column      = 30
width       = 1
md          = 9
catlabels   = 1 GREAT DEAL
              2 QUITE A BIT
              3 NOT VERY MUCH
              4 NONE
              8 DK
              9 REFUSE
*
name        = Q27
label       = CONFIDENCE IN COURTS
type        = numeric
record      = 1
column      = 31
width       = 1
md          = 9
catlabels   = 1 GREAT DEAL
              2 QUITE A BIT
              3 NOT VERY MUCH
              4 NONE
              8 DK
              9 REFUSE
*
name        = Q28
label       = TOUGHER GUN CONTROL LAWS
type        = numeric
record      = 1
column      = 32
width       = 1
md          = 9
catlabels   = 1 STRONGLY FAVOR
              2 SOMEWHAT FAVOR
              3 SOMEWHAT OPPOSE
              4 STRONGLY OPPOSE
              8 DK
              9 REFUSE
*
name        = Q29
label       = POP GROWTH IN CITY PAST FEW YRS
type        = numeric
record      = 1
column      = 33
width       = 1
md          = 9
catlabels   = 1 GROWING RAPIDLY
              2 GROWING SLOWLY
              3 STAYING SAME
              4 LOSING POP
              8 DK
              9 REFUSE
*
name        = Q30
label       = CURRENT GROWTH REGS IN CITY
type        = numeric
record      = 1
column      = 34
width       = 1
md          = 9
catlabels   = 1 TOO STRICT
              2 ABOUT RIGHT
              3 NOT STRICT ENOUGH
              9 DK,REFUSE
*
name        = Q31
label       = FEELING ABOUT FREEWAYS IN OC
type        = numeric
record      = 1
column      = 35
width       = 1
md          = 9
catlabels   = 1 SATISFACTORY
              2 MORE LANES ONLY
              3 NEW FREEWAYS
              9 DK, REFUSE
*
name        = Q32
label       = WORK STATUS
type        = numeric
record      = 1
column      = 36
width       = 1
md          = 9
catlabels   = 1 FULL-TIME
              2 PART-TIME
              3 NOT EMPLOYED
              9 REFUSE
*
name        = Q33
label       = HOW COMMUTE TO WORK
type        = numeric
record      = 1
column      = 37
width       = 1
md          = 9
catlabels   = 1 DRIVE ALONE
              2 CARPOOL
              3 VANPOOL
              4 PUBLIC TRANSIT
              5 OTHER
              9 DK, REFUSE
*
name        = Q34
label       = TRAFFIC CONGESTION DURING COMMUTE
type        = numeric
record      = 1
column      = 38
width       = 1
md          = 9
catlabels   = 1 NO PROBLEM
              2 SOME PROBLEM
              3 GREAT PROBLEM
              9 NA
*
name        = Q35
label       = HOW SERIOUS A THREAT ARE ENV PROBS
type        = numeric
record      = 1
column      = 39
width       = 1
md          = 9
catlabels   = 1 VERY SERIOUS
              2 SOMEWHAT SERIOUS
              3 NOT TOO SERIOUS
              8 DK
              9 REFUSE
*
name        = Q36
label       = STORM DRAINS AND SEWERS ON SAME SYSTEM
type        = numeric
record      = 1
column      = 40
width       = 1
md          = 9
catlabels   = 1 STRONGLY AGREE
              2 SOMEWHAT AGREE
              3 SOMEWHAT DISAGREE
              4 STRONGLY DISAGREE
              8 DK
              9 REFUSE
*
name        = Q37
label       = STORM DRAIN WATER IS TREATED
type        = numeric
record      = 1
column      = 41
width       = 1
md          = 9
catlabels   = 1 STRONGLY AGREE
              2 SOMEWHAT AGREE
              3 SOMEWHAT DISAGREE
              4 STRONGLY DISAGREE
              8 DK
              9 REFUSE
*
name        = Q38
label       = ILLEGAL TO THROW THINGS IN STORM DRAINS
type        = numeric
record      = 1
column      = 42
width       = 1
md          = 9
catlabels   = 1 STRONGLY AGREE
              2 SOMEWHAT AGREE
              3 SOMEWHAT DISAGREE
              4 STRONGLY DISAGREE
              8 DK
              9 REFUSE
*
name        = Q39
label       = SEEN ANNOUNCEMENTS ABOUT DUMPING
type        = numeric
record      = 1
column      = 43
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q40
label       = SEEN 'OCEAN BEGINS...' BROCHURE
type        = numeric
record      = 1
column      = 44
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q41
label       = SEEN STENCILLING ON CURBS
type        = numeric
record      = 1
column      = 45
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q42
label       = SANTA ANA RIVER IS FLOOD THREAT
type        = numeric
record      = 1
column      = 46
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q43
label       = YR RESIDENCE IN A FLOOD PLAIN
type        = numeric
record      = 1
column      = 47
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q44
label       = SEEN ANNOUNCEMENTS ABOUT FLOODING
type        = numeric
record      = 1
column      = 48
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q45
label       = SEEN FLOOD AWARENESS BROCHURES
type        = numeric
record      = 1
column      = 49
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q46
label       = MINORITIES HAVE PROBLEMS LIVING HERE
type        = numeric
record      = 1
column      = 50
width       = 1
md          = 9
catlabels   = 1 VERY SERIOUS
              2 SOMEWHAT SERIOUS
              3 NOT SERIOUS
              8 DK
              9 REFUSE
*
name        = Q47
label       = ETHNIC RELATIONS IN OC
type        = numeric
record      = 1
column      = 51
width       = 1
md          = 9
catlabels   = 1 IN CONFLICT
              2 GETTING ALONG
              8 DK
              9 REFUSE
*
name        = Q48
label       = RELATIONS NEXT 10 YRS
type        = numeric
record      = 1
column      = 52
width       = 1
md          = 9
catlabels   = 1 IMPROVE A LOT
              2 IMPROVE SOMEWHAT
              3 STAY SAME
              4 GET SOMEWHAT WORSE
              5 GET A LOT WORSE
              8 DK
              9 REFUSE
*
name        = Q49
label       = ETHNIC VARIETY IMPACT ON QUALITY OF LIFE
type        = numeric
record      = 1
column      = 53
width       = 1
md          = 9
catlabels   = 1 HELPED
              2 HURT
              8 DK
              9 REFUSE
*
name        = Q50
label       = ETHNIC VARIETY IMPACT ON LOCAL GOVT
type        = numeric
record      = 1
column      = 54
width       = 1
md          = 9
catlabels   = 1 EASIER
              2 HARDER
              8 DK
              9 REFUSE
*
name        = Q51
label       = ETHNIC VARIETY IMPACT ON LOCAL ECONOMY
type        = numeric
record      = 1
column      = 55
width       = 1
md          = 9
catlabels   = 1 HELPED
              2 HURT
              8 DK
              9 REFUSE
*
name        = Q52
label       = EXPERIENCE ETHNIC DISCRIMINATION
type        = numeric
record      = 1
column      = 56
width       = 1
md          = 9
catlabels   = 1 ALWAYS
              2 FREQUENTLY
              3 OCCASIONALLY
              4 SELDOM
              5 NEVER
              8 DK
              9 REFUSE
*
name        = Q53
label       = OTHERS IN ETHNIC GP EXPERIENCE DISCRIMIN
type        = numeric
record      = 1
column      = 57
width       = 1
md          = 9
catlabels   = 1 ALWAYS
              2 FREQUENTLY
              3 OCCASIONALLY
              4 SELDOM
              5 NEVER
              8 DK
              9 REFUSE
*
name        = Q54
label       = MAKEUP OF NEIGHBORHOOD CHANGING
type        = numeric
record      = 1
column      = 58
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q55
label       = CHANGE GOOD/BAD FOR NBHD
type        = numeric
record      = 1
column      = 59
width       = 1
md          = 9
catlabels   = 1 GOOD
              2 BAD
              8 DK
              9 REFUSE
*
name        = Q56
label       = HOW FEEL W/ PEOPLE FROM DIFF ETHNIC GPS
type        = numeric
record      = 1
column      = 60
width       = 1
md          = 9
catlabels   = 1 VERY UNEASY
              2 SOMEWHAT UNEASY
              3 NEITHER
              4 SOMEWHAT RELAXED
              5 VERY RELAXED
              8 DK
              9 REFUSE
*
name        = Q57
label       = FELT PRESSURE NOT TO SOCIALIZE W/ OTHER
type        = numeric
record      = 1
column      = 61
width       = 1
md          = 9
catlabels   = 1 VERY OFTEN
              2 SOMEWHAT OFTEN
              3 NOW AND THEN
              4 RARELY
              5 NEVER
              8 DK
              9 REFUSE
*
name        = Q58
label       = YOUR ETHNIC IDENTITY
type        = numeric
record      = 1
column      = 62
width       = 1
md          = 9
catlabels   = 1 JUST AN AMERICAN
              2 SPEC ETHNIC GP
              3 2+ ETHNIC GPS
              4 AM &  ETHNIC GP
              5 DEPENDS
              8 DK
              9 REFUSE
*
name        = Q59
label       = VIEWS ON MELTING POT
type        = numeric
record      = 1
column      = 63
width       = 1
md          = 9
catlabels   = 1 1 DISTINCT CULTURES
              2 2
              3 3
              4 4
              5 5
              6 6
              7 7 BLEND IN
              8 DK
              9 REFUSE
*
name        = Q60
label       = ATTENTION GIVEN TO MINORITIES IN HISTORY
type        = numeric
record      = 1
column      = 64
width       = 1
md          = 9
catlabels   = 1 TOO MUCH
              2 TOO LITTLE
              3 ABOUT RIGHT
              8 DK
              9 REFUSE
*
name        = Q61
label       = PROGRAMS TO INCREASE DIALOGUE
type        = numeric
record      = 1
column      = 65
width       = 1
md          = 9
catlabels   = 1 A LOT
              2 SOMEWHAT
              3 VERY LITTLE
              4 NOT AT ALL
              8 DK
              9 REFUSE
*
name        = Q62
label       = PROGRAMS TO RAISE PUBLIC UNDERSTANDING
type        = numeric
record      = 1
column      = 66
width       = 1
md          = 9
catlabels   = 1 A LOT
              2 SOMEWHAT
              3 VERY LITTLE
              4 NOT AT ALL
              8 DK
              9 REFUSE
*
name        = Q63
label       = HOW IMPT EFFORTS TO OC ECONOMY
type        = numeric
record      = 1
column      = 67
width       = 1
md          = 9
catlabels   = 1 VERY IMPT
              2 SOMEWHAT IMPT
              3 SOMEWHAT UNIMPT
              4 VERY UNIMPT
              8 DK
              9 REFUSE
*
name        = Q64
label       = HOW IMPT EFFORTS TO OC QUALITY OF LIFE
type        = numeric
record      = 1
column      = 68
width       = 1
md          = 9
catlabels   = 1 VERY IMPT
              2 SOMEWHAT IMPT
              3 SOMEWHAT UNIMPT
              4 VERY UNIMPT
              8 DK
              9 REFUSE
*
name        = Q65
label       = RESPONSIBILITY FOR IMPROVING RELATIONS
type        = numeric
record      = 1
column      = 69
width       = 1
md          = 9
catlabels   = 1 GOVT
              2 INDIVIDUALS
              3 SCHOOLS
              4 NONPROFIT ORGS
              5 CHURCHES
              6 BUSINESSES
              7 OTHER
              8 DK
              9 REFUSE
*
name        = Q66
label       = HOW IMPT VOLUNTEER WORK
type        = numeric
record      = 1
column      = 70
width       = 1
md          = 9
catlabels   = 1 ESSENTIAL
              2 VERY IMPT
              3 SOMEWHAT IMPT
              4 NOT VERY IMPT
              5 NOT AT ALL IMPT
              8 DK
              9 REFUSE
*
name        = Q67
label       = VOLUNTEERED IN PAST 12 MO
type        = numeric
record      = 1
column      = 71
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q68
label       = HOW MANY ORGS VOLUNTEERED FOR
type        = numeric
record      = 1
column      = 72
width       = 1
md          = 9
catlabels   = 1 ONE
              2 MORE THAN ONE
              8 DK
              9 REFUSE
*
name        = Q69
label       = HOURS SPENT VOLUNTEERING IN PAST MO
type        = numeric
record      = 1
column      = 73
width       = 1
md          = 9
catlabels   = 1 NO TIME
              2 LESS THAN 1 HR
              3 1 HR
              4 2-4 HRS
              5 5+ HRS
              8 DK
              9 REFUSE
*
name        = Q70
label       = HOW LEARNED ABOUT VOL ACTIVITIES
type        = numeric
record      = 1
column      = 74
width       = 1
md          = 9
catlabels   = 1 ASKED BY SOMEONE
              2 FAM MEMB IN ORG
              3 THROUGH ORG
              4 SAW AD
              5 ON OWN
              6 VOLUNTEER CENTER
              7 OTHER
              8 DK
              9 REFUSE
*
name        = Q71
label       = WHY NOT A VOLUNTEER
type        = numeric
record      = 1
column      = 75
width       = 1
md          = 9
catlabels   = 1 TOO BUSY
              2 UNABLE TO HONOR
              3 NOT INTERESTED
              4 DONT KNOW HOW
              5 NO ONE ASKED
              6 WOULDNT MAKE DIFF
              7 OTHER
              8 DK
              9 REFUSE
*
name        = Q72
label       = MOST IMPT REASON FOR VOLUNTEERING
type        = numeric
record      = 1
column      = 76
width       = 1
md          = 9
catlabels   = 1 ENJOY WORK
              2 FEEL NEEDED
              3 IMPORTANT TO HELP
              4 FAM IN ACTIVITY
              5 LEARN NEW SKILLS
              6 MAKE CONTACTS
              7 OTHER
              8 DK
              9 REFUSE
*
name        = Q73
label       = VOLUNTEER'S IMPACT ON COMMUNITY PROBLEMS
type        = numeric
record      = 1
column      = 77
width       = 1
md          = 9
catlabels   = 1 BIG DIFF
              2 SOME DIFF
              3 SMALL DIFF
              4 NO DIFF
              8 DK
              9 REFUSE
*
name        = Q74
label       = VOLUNTEER INFO ORG HELPFUL
type        = numeric
record      = 1
column      = 78
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q75
label       = HEARD ABOUT VOLUNTEER CENTER
type        = numeric
record      = 1
column      = 79
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q76
label       = $ GAVE TO ALL CHARITIES LAST YR
type        = numeric
record      = 1
column      = 80
width       = 1
md          = 9
catlabels   = 1 NOTHING
              2 $1-$100
              3 $101-$250
              4 $251-$500
              5 $501-$999
              6 $1000+
              9 DK, REFUSE
*
name        = Q77
label       = AGE
type        = numeric
record      = 1
column      = 81
width       = 1
md          = 9
catlabels   = 1 18-34
              2 35-54
              3 55+
              9 REFUSE
*
name        = Q78
label       = EDUCATION
type        = numeric
record      = 1
column      = 82
width       = 1
md          = 9
catlabels   = 1 < H.S.
              2 H.S. GRAD
              3 SOME COLLEGE
              4 COLLEGE GRAD
              5 POST GRAD
              9 REFUSE
*
name        = Q79
label       = NUMBER OF CHILDREN IN HHOLD
type        = numeric
record      = 1
column      = 83
width       = 1
md          = 9
catlabels   = 0 NONE
              1 ONE
              2 TWO
              3 THREE OR MORE
              9 REFUSE
*
name        = Q80
label       = RESIDENCE
type        = numeric
record      = 1
column      = 84
width       = 2
catlabels   = 1 NORTH
              2 WEST
              3 CENTRAL
              4 SOUTH
              5 OUTSIDE OC
              9 NO ANS
*
name        = Q81
label       = ANNUAL HOUSEHOLD INCOME
type        = numeric
record      = 1
column      = 86
width       = 1
md          = 9
catlabels   = 1 UNDER $36,000
              2 $36,000-$50,000
              3 $50,001-$79,999
              4 $80,000+
              9 DK, REFUSE
*
name        = Q82
label       = CONSIDER YOURSELF POLITICALLY:
type        = numeric
record      = 1
column      = 87
width       = 1
md          = 9
catlabels   = 1 VERY LIBERAL
              2 SOMEWHAT LIBERAL
              3 MIDDLE OF ROAD
              4 SOMEWHAT CONSERV
              5 VERY CONSERV
              9 REFUSE
*
name        = Q83
label       = PARTY
type        = numeric
record      = 1
column      = 88
width       = 1
md          = 9
catlabels   = 1 DEMOCRAT
              2 REPUBLICAN
              3 INDEP/OTHER
              4 NOT REGISTERED
              9 REFUSE
*
name        = Q84
label       = VOTE FOR GOVERNOR
type        = numeric
record      = 1
column      = 89
width       = 1
md          = 9
catlabels   = 1 WILSON
              2 BROWN
              3 OTHER
              8 DK
              9 REFUSE
*
name        = Q85
label       = VOTE FOR U.S. SENATOR
type        = numeric
record      = 1
column      = 90
width       = 1
md          = 9
catlabels   = 1 HUFFINGTON
              2 FEINSTEIN
              3 OTHER
              8 DK
              9 REFUSE
*
name        = Q86
label       = VOTE ON PROP 184 (THREE STRIKES)
type        = numeric
record      = 1
column      = 91
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q87
label       = VOTE ON PROP 187 (SAVE OUR STATE)
type        = numeric
record      = 1
column      = 92
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q88
label       = VOTE ON MEASURE R (EL TORO AIRPORT)
type        = numeric
record      = 1
column      = 93
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
*
name        = Q89
label       = EL TORO AIRPORT WD CREATE JOBS
type        = numeric
record      = 1
column      = 94
width       = 1
md          = 9
catlabels   = 1 STRONGLY AGREE
              2 SOMEWHAT AGREE
              3 SOMEWHAT DISAGREE
              4 STRONGLY DISAGREE
              8 DK
              9 REFUSE
*
name        = Q90
label       = EL TORO AIRPORT WD BE TOO NOISY
type        = numeric
record      = 1
column      = 95
width       = 1
md          = 9
catlabels   = 1 STRONGLY AGREE
              2 SOMEWHAT AGREE
              3 SOMEWHAT DISAGREE
              4 STRONGLY DISAGREE
              8 DK
              9 REFUSE
*
name        = Q91
label       = AIRPORT MOST FISCALLY SOUND OPTION
type        = numeric
record      = 1
column      = 96
width       = 1
md          = 9
catlabels   = 1 STRONGLY AGREE
              2 SOMEWHAT AGREE
              3 SOMEWHAT DISAGREE
              4 STRONGLY DISAGREE
              8 DK
              9 REFUSE
*
name        = Q92
label       = VOTED IN PAST 4 YRS
type        = numeric
record      = 1
column      = 97
width       = 1
md          = 9
catlabels   = 0 NEVER
              1 1X
              2 2X
              3 3X
              4 4X+
              8 DK
              9 REFUSE
*
name        = Q93
label       = RACE
type        = numeric
record      = 1
column      = 98
width       = 1
md          = 9
catlabels   = 1 ASIAN
              2 BLACK
              3 HISPANIC
              4 CAUCASIAN
              5 OTHER
              9 REFUSE
*
name        = Q94
label       = SEX
type        = numeric
record      = 1
column      = 99
width       = 1
catlabels   = 1 MALE
              2 FEMALE
*
name        = LANG
label       = LANGUAGE OF INTERVIEW
type        = numeric
record      = 1
column      = 100
width       = 1
catlabels   = 1 ENGLISH
              2 SPANISH
*
name        = WEIGHT
label       = WEIGHT
type        = numeric
record      = 1
column      = 101
width       = 8
decimals    = 2
*
name        = WT
label       = WT
type        = numeric
record      = 1
column      = 109
width       = 8
decimals    = 2
*
name        = YEAR
label       = YEAR OF SURVEY
type        = numeric
record      = 1
column      = 117
width       = 4
catlabels   = 1994 YEAR OF SURVEY
