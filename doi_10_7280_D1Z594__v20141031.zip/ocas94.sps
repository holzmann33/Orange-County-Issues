 /*  SPSS Data Definition File
 /*  Created by ddltox on Jan 13, 2003  (Mon 03:47 PM PST)
 /*  DDL source file: "/u/d7/big/sda_1.2a/tmpdir/AAxmaaNF.txt".

TITLE "ORANGE COUNTY SURVEYS".
COMMENT  DDL indicates that dataset record length (reclen) is 120 columns.

DATA LIST fixed records=1
  FILE=x  /* Replace 'x' with name(within quotes) of your input data file
 /1           CASEID 1-4                    Q1 5                    Q2 6
                    Q3 7                    Q4 8                    Q5 9
                   Q6 10                   Q7 11                   Q8 12
                   Q9 13                  Q10 14                  Q11 15
                  Q12 16                  Q13 17                  Q14 18
                  Q15 19                  Q16 20                  Q17 21
                  Q18 22                  Q19 23                  Q20 24
                  Q21 25                  Q22 26                  Q23 27
                  Q24 28                  Q25 29                  Q26 30
                  Q27 31                  Q28 32                  Q29 33
                  Q30 34                  Q31 35                  Q32 36
                  Q33 37                  Q34 38                  Q35 39
                  Q36 40                  Q37 41                  Q38 42
                  Q39 43                  Q40 44                  Q41 45
                  Q42 46                  Q43 47                  Q44 48
                  Q45 49                  Q46 50                  Q47 51
                  Q48 52                  Q49 53                  Q50 54
                  Q51 55                  Q52 56                  Q53 57
                  Q54 58                  Q55 59                  Q56 60
                  Q57 61                  Q58 62                  Q59 63
                  Q60 64                  Q61 65                  Q62 66
                  Q63 67                  Q64 68                  Q65 69
                  Q66 70                  Q67 71                  Q68 72
                  Q69 73                  Q70 74                  Q71 75
                  Q72 76                  Q73 77                  Q74 78
                  Q75 79                  Q76 80                  Q77 81
                  Q78 82                  Q79 83               Q80 84-85
                  Q81 86                  Q82 87                  Q83 88
                  Q84 89                  Q85 90                  Q86 91
                  Q87 92                  Q88 93                  Q89 94
                  Q90 95                  Q91 96                  Q92 97
                  Q93 98                  Q94 99                LANG 100
      WEIGHT 101-108 (2)          WT 109-116 (2)            YEAR 117-120

   .

VARIABLE LABELS
   CASEID    'CASE ID' /
   Q1        'TYPE OF CURRENT RESIDENCE' /
   Q2        'HOW LONG LIVE IN OC' /
   Q3        'HOW LONG LIVE AT CURRENT RESIDENCE' /
   Q4        'OWN/RENT PRESENT RESIDENCE' /
   Q5        'MONTHLY RENTAL PAYMENT' /
   Q6        'MONTHLY MORTGAGE PAYMENT' /
   Q7        'BETTER OFF/WORSE OFF/SAME LAST YEAR' /
   Q8        'BETTER OFF/WORSE OFF/SAME NEXT YEAR' /
   Q9        'NAT''L BUSINESS CONDS NEXT 12 MO' /
   Q10       'NAT''L CONDS NEXT 5 YEARS' /
   Q11       'GD/BAD TIME TO BUY MAJ HSEHOLD ITEMS' /
   Q12       'RATE ECONOMY IN OC TODAY' /
   Q13       'OC ECONOMY 2 YRS FROM NOW' /
   Q14       'BUYING OC HOME GOOD INVESTMENT TODAY' /
   Q15       'QUALITY OF LIFE IN OC' /
   Q16       'MOST SERIOUS PUBLIC POLICY PROBLEM' /
   Q17       'MOST SERIOUS SOCIAL PROBLEM' /
   Q18       'OC IN FUTURE' /
   Q19       'CRIME A PROBLEM IN OC' /
   Q20       'CRIME FEAR KEEPS YOU FROM SHOPPING' /
   Q21       'CRIME FEAR KEEPS YOU FROM PARKS' /
   Q22       'CRIME FEAR KEEPS YOU FROM MOVIES' /
   Q23       'FEARFUL THAT WILL BE CRIME VICTIM' /
   Q24       'ATTENTION TO CRIME NEWS IN NEWSPAPERS' /
   Q25       'ATTENTION TO CRIME NEWS ON TV' /
   Q26       'CONFIDENCE IN POLICE' /
   Q27       'CONFIDENCE IN COURTS' /
   Q28       'TOUGHER GUN CONTROL LAWS' /
   Q29       'POP GROWTH IN CITY PAST FEW YRS' /
   Q30       'CURRENT GROWTH REGS IN CITY' /
   Q31       'FEELING ABOUT FREEWAYS IN OC' /
   Q32       'WORK STATUS' /
   Q33       'HOW COMMUTE TO WORK' /
   Q34       'TRAFFIC CONGESTION DURING COMMUTE' /
   Q35       'HOW SERIOUS A THREAT ARE ENV PROBS' /
   Q36       'STORM DRAINS AND SEWERS ON SAME SYSTEM' /
   Q37       'STORM DRAIN WATER IS TREATED' /
   Q38       'ILLEGAL TO THROW THINGS IN STORM DRAINS' /
   Q39       'SEEN ANNOUNCEMENTS ABOUT DUMPING' /
   Q40       'SEEN ''OCEAN BEGINS...'' BROCHURE' /
   Q41       'SEEN STENCILLING ON CURBS' /
   Q42       'SANTA ANA RIVER IS FLOOD THREAT' /
   Q43       'YR RESIDENCE IN A FLOOD PLAIN' /
   Q44       'SEEN ANNOUNCEMENTS ABOUT FLOODING' /
   Q45       'SEEN FLOOD AWARENESS BROCHURES' /
   Q46       'MINORITIES HAVE PROBLEMS LIVING HERE' /
   Q47       'ETHNIC RELATIONS IN OC' /
   Q48       'RELATIONS NEXT 10 YRS' /
   Q49       'ETHNIC VARIETY IMPACT ON QUALITY OF LIFE' /
   Q50       'ETHNIC VARIETY IMPACT ON LOCAL GOVT' /
   Q51       'ETHNIC VARIETY IMPACT ON LOCAL ECONOMY' /
   Q52       'EXPERIENCE ETHNIC DISCRIMINATION' /
   Q53       'OTHERS IN ETHNIC GP EXPERIENCE DISCRIMIN' /
   Q54       'MAKEUP OF NEIGHBORHOOD CHANGING' /
   Q55       'CHANGE GOOD/BAD FOR NBHD' /
   Q56       'HOW FEEL W/ PEOPLE FROM DIFF ETHNIC GPS' /
   Q57       'FELT PRESSURE NOT TO SOCIALIZE W/ OTHER' /
   Q58       'YOUR ETHNIC IDENTITY' /
   Q59       'VIEWS ON MELTING POT' /
   Q60       'ATTENTION GIVEN TO MINORITIES IN HISTORY' /
   Q61       'PROGRAMS TO INCREASE DIALOGUE' /
   Q62       'PROGRAMS TO RAISE PUBLIC UNDERSTANDING' /
   Q63       'HOW IMPT EFFORTS TO OC ECONOMY' /
   Q64       'HOW IMPT EFFORTS TO OC QUALITY OF LIFE' /
   Q65       'RESPONSIBILITY FOR IMPROVING RELATIONS' /
   Q66       'HOW IMPT VOLUNTEER WORK' /
   Q67       'VOLUNTEERED IN PAST 12 MO' /
   Q68       'HOW MANY ORGS VOLUNTEERED FOR' /
   Q69       'HOURS SPENT VOLUNTEERING IN PAST MO' /
   Q70       'HOW LEARNED ABOUT VOL ACTIVITIES' /
   Q71       'WHY NOT A VOLUNTEER' /
   Q72       'MOST IMPT REASON FOR VOLUNTEERING' /
   Q73       'VOLUNTEER''S IMPACT ON COMMUNITY PROBLEMS' /
   Q74       'VOLUNTEER INFO ORG HELPFUL' /
   Q75       'HEARD ABOUT VOLUNTEER CENTER' /
   Q76       '$ GAVE TO ALL CHARITIES LAST YR' /
   Q77       'AGE' /
   Q78       'EDUCATION' /
   Q79       'NUMBER OF CHILDREN IN HHOLD' /
   Q80       'RESIDENCE' /
   Q81       'ANNUAL HOUSEHOLD INCOME' /
   Q82       'CONSIDER YOURSELF POLITICALLY:' /
   Q83       'PARTY' /
   Q84       'VOTE FOR GOVERNOR' /
   Q85       'VOTE FOR U.S. SENATOR' /
   Q86       'VOTE ON PROP 184 (THREE STRIKES)' /
   Q87       'VOTE ON PROP 187 (SAVE OUR STATE)' /
   Q88       'VOTE ON MEASURE R (EL TORO AIRPORT)' /
   Q89       'EL TORO AIRPORT WD CREATE JOBS' /
   Q90       'EL TORO AIRPORT WD BE TOO NOISY' /
   Q91       'AIRPORT MOST FISCALLY SOUND OPTION' /
   Q92       'VOTED IN PAST 4 YRS' /
   Q93       'RACE' /
   Q94       'SEX' /
   LANG      'LANGUAGE OF INTERVIEW' /
   WEIGHT    'WEIGHT' /
   WT        'WT' /
   YEAR      'YEAR OF SURVEY' /
   .

VALUE LABELS
   Q1        1 'SINGLE FAMILY' 2 'ATTACHED' 3 'APARTMENT' 4 'MOBILE' 
             5 'OTHER' 9 'REFUSE' /
   Q2        1 '0-2 YRS' 2 '3-5 YRS' 3 '6-10 YRS' 4 '11-20 YRS' 5 '21+ YRS' 
             9 'REFUSE' /
   Q3        1 '0-2 YRS' 2 '3-5 YRS' 3 '6-10 YRS' 4 '11-20 YRS' 5 '21+ YRS' 
             9 'REFUSE' /
   Q4        1 'OWN' 2 'RENT' 9 'DK, REFUSE' /
   Q5        1 'UNDER $500' 2 '$501-$750' 3 '$751-$1,000' 4 '$1,001-$1,500' 
             5 '$1,501+' 9 'NA, REFUSE' /
   Q6        1 'NOTHING' 2 '$1-$500' 3 '$501-$750' 4 '$751-$1,000' 
             5 '$1,001-$1,500' 6 '$1,501-$2,000' 7 '$2,001+' 9 'NA, REFUSE' /
   Q7        1 'BETTER OFF' 2 'WORSE OFF' 3 'SAME' 9 'DK, REFUSE' /
   Q8        1 'BETTER OFF' 2 'WORSE OFF' 3 'SAME' 8 'DK' 9 'REFUSE' /
   Q9        1 'GOOD TIMES' 2 'BAD TIMES' 8 'DK' 9 'REFUSE' /
   Q10       1 'GOOD TIMES' 2 'DEPRESSION' 8 'DK' 9 'REFUSE' /
   Q11       1 'GOOD TIME' 2 'BAD TIME' 8 'NEITHER, DK' 9 'REFUSE' /
   Q12       1 'EXCELLENT' 2 'GOOD' 3 'FAIR' 4 'POOR' 8 'DK' 9 'REFUSE' /
   Q13       1 'MUCH BETTER' 2 'SOMEWHAT BETTER' 3 'SAME' 4 'SOMEWHAT WORSE' 
             5 'MUCH WORSE' 8 'DK' 9 'REFUSE' /
   Q14       1 'EXCELLENT' 2 'GOOD' 3 'FAIR' 4 'POOR' 8 'DK' 9 'REFUSE' /
   Q15       1 'VERY WELL' 2 'SOMEWHAT WELL' 3 'SOMEWHAT BADLY' 
             4 'VERY BADLY' 9 'DK, REFUSE' /
   Q16       1 'GROWTH' 2 'TRAFFIC' 3 'HOUSING' 4 'CRIME' 5 'SCHOOLS' 
             6 'IMMIGRATION' 7 'ECONOMY' 8 'OTHER' 9 'DK, REFUSE' /
   Q17       1 'HEALTH CARE' 2 'CHILD CARE' 3 'RACE RELATIONS' 4 'HOMELESS' 
             5 'DRUG ABUSE' 6 'AIDS' 7 'OTHER' 9 'DK, REFUSE' /
   Q18       1 'BETTER PLACE' 2 'WORSE PLACE' 3 'NO CHANGE' 9 'DK, REFUSE' /
   Q19       1 'BIG PROBLEM' 2 'SOME PROBLEM' 3 'SMALL PROBLEM' 
             4 'NO PROBLEM' 8 'DK' 9 'REFUSE' /
   Q20       1 'VERY OFTEN' 2 'SOMETIMES' 3 'RARELY' 4 'NEVER' 8 'DK' 
             9 'REFUSE' /
   Q21       1 'VERY OFTEN' 2 'SOMETIMES' 3 'RARELY' 4 'NEVER' 8 'DK' 
             9 'REFUSE' /
   Q22       1 'VERY OFTEN' 2 'SOMETIMES' 3 'RARELY' 4 'NEVER' 8 'DK' 
             9 'REFUSE' /
   Q23       1 'VERY FEARFUL' 2 'SOMEWHAT FEARFUL' 3 'NOT TOO FEARFUL' 
             4 'NOT FEARFUL' 8 'DK' 9 'REFUSE' /
   Q24       1 'GREAT DEAL' 2 'SOME' 3 'NOT MUCH' 4 'NONE' 8 'DK' 9 'REFUSE' /
   Q25       1 'GREAT DEAL' 2 'SOME' 3 'NOT MUCH' 4 'NONE' 8 'DK' 9 'REFUSE' /
   Q26       1 'GREAT DEAL' 2 'QUITE A BIT' 3 'NOT VERY MUCH' 4 'NONE' 8 'DK' 
             9 'REFUSE' /
   Q27       1 'GREAT DEAL' 2 'QUITE A BIT' 3 'NOT VERY MUCH' 4 'NONE' 8 'DK' 
             9 'REFUSE' /
   Q28       1 'STRONGLY FAVOR' 2 'SOMEWHAT FAVOR' 3 'SOMEWHAT OPPOSE' 
             4 'STRONGLY OPPOSE' 8 'DK' 9 'REFUSE' /
   Q29       1 'GROWING RAPIDLY' 2 'GROWING SLOWLY' 3 'STAYING SAME' 
             4 'LOSING POP' 8 'DK' 9 'REFUSE' /
   Q30       1 'TOO STRICT' 2 'ABOUT RIGHT' 3 'NOT STRICT ENOUGH' 
             9 'DK,REFUSE' /
   Q31       1 'SATISFACTORY' 2 'MORE LANES ONLY' 3 'NEW FREEWAYS' 
             9 'DK, REFUSE' /
   Q32       1 'FULL-TIME' 2 'PART-TIME' 3 'NOT EMPLOYED' 9 'REFUSE' /
   Q33       1 'DRIVE ALONE' 2 'CARPOOL' 3 'VANPOOL' 4 'PUBLIC TRANSIT' 
             5 'OTHER' 9 'DK, REFUSE' /
   Q34       1 'NO PROBLEM' 2 'SOME PROBLEM' 3 'GREAT PROBLEM' 9 'NA' /
   Q35       1 'VERY SERIOUS' 2 'SOMEWHAT SERIOUS' 3 'NOT TOO SERIOUS' 8 'DK' 
             9 'REFUSE' /
   Q36       1 'STRONGLY AGREE' 2 'SOMEWHAT AGREE' 3 'SOMEWHAT DISAGREE' 
             4 'STRONGLY DISAGREE' 8 'DK' 9 'REFUSE' /
   Q37       1 'STRONGLY AGREE' 2 'SOMEWHAT AGREE' 3 'SOMEWHAT DISAGREE' 
             4 'STRONGLY DISAGREE' 8 'DK' 9 'REFUSE' /
   Q38       1 'STRONGLY AGREE' 2 'SOMEWHAT AGREE' 3 'SOMEWHAT DISAGREE' 
             4 'STRONGLY DISAGREE' 8 'DK' 9 'REFUSE' /
   Q39       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q40       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q41       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q42       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q43       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q44       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q45       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q46       1 'VERY SERIOUS' 2 'SOMEWHAT SERIOUS' 3 'NOT SERIOUS' 8 'DK' 
             9 'REFUSE' /
   Q47       1 'IN CONFLICT' 2 'GETTING ALONG' 8 'DK' 9 'REFUSE' /
   Q48       1 'IMPROVE A LOT' 2 'IMPROVE SOMEWHAT' 3 'STAY SAME' 
             4 'GET SOMEWHAT WORSE' 5 'GET A LOT WORSE' 8 'DK' 9 'REFUSE' /
   Q49       1 'HELPED' 2 'HURT' 8 'DK' 9 'REFUSE' /
   Q50       1 'EASIER' 2 'HARDER' 8 'DK' 9 'REFUSE' /
   Q51       1 'HELPED' 2 'HURT' 8 'DK' 9 'REFUSE' /
   Q52       1 'ALWAYS' 2 'FREQUENTLY' 3 'OCCASIONALLY' 4 'SELDOM' 5 'NEVER' 
             8 'DK' 9 'REFUSE' /
   Q53       1 'ALWAYS' 2 'FREQUENTLY' 3 'OCCASIONALLY' 4 'SELDOM' 5 'NEVER' 
             8 'DK' 9 'REFUSE' /
   Q54       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q55       1 'GOOD' 2 'BAD' 8 'DK' 9 'REFUSE' /
   Q56       1 'VERY UNEASY' 2 'SOMEWHAT UNEASY' 3 'NEITHER' 
             4 'SOMEWHAT RELAXED' 5 'VERY RELAXED' 8 'DK' 9 'REFUSE' /
   Q57       1 'VERY OFTEN' 2 'SOMEWHAT OFTEN' 3 'NOW AND THEN' 4 'RARELY' 
             5 'NEVER' 8 'DK' 9 'REFUSE' /
   Q58       1 'JUST AN AMERICAN' 2 'SPEC ETHNIC GP' 3 '2+ ETHNIC GPS' 
             4 'AM &  ETHNIC GP' 5 'DEPENDS' 8 'DK' 9 'REFUSE' /
   Q59       1 '1 DISTINCT CULTURES' 2 '2' 3 '3' 4 '4' 5 '5' 6 '6' 
             7 '7 BLEND IN' 8 'DK' 9 'REFUSE' /
   Q60       1 'TOO MUCH' 2 'TOO LITTLE' 3 'ABOUT RIGHT' 8 'DK' 9 'REFUSE' /
   Q61       1 'A LOT' 2 'SOMEWHAT' 3 'VERY LITTLE' 4 'NOT AT ALL' 8 'DK' 
             9 'REFUSE' /
   Q62       1 'A LOT' 2 'SOMEWHAT' 3 'VERY LITTLE' 4 'NOT AT ALL' 8 'DK' 
             9 'REFUSE' /
   Q63       1 'VERY IMPT' 2 'SOMEWHAT IMPT' 3 'SOMEWHAT UNIMPT' 
             4 'VERY UNIMPT' 8 'DK' 9 'REFUSE' /
   Q64       1 'VERY IMPT' 2 'SOMEWHAT IMPT' 3 'SOMEWHAT UNIMPT' 
             4 'VERY UNIMPT' 8 'DK' 9 'REFUSE' /
   Q65       1 'GOVT' 2 'INDIVIDUALS' 3 'SCHOOLS' 4 'NONPROFIT ORGS' 
             5 'CHURCHES' 6 'BUSINESSES' 7 'OTHER' 8 'DK' 9 'REFUSE' /
   Q66       1 'ESSENTIAL' 2 'VERY IMPT' 3 'SOMEWHAT IMPT' 4 'NOT VERY IMPT' 
             5 'NOT AT ALL IMPT' 8 'DK' 9 'REFUSE' /
   Q67       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q68       1 'ONE' 2 'MORE THAN ONE' 8 'DK' 9 'REFUSE' /
   Q69       1 'NO TIME' 2 'LESS THAN 1 HR' 3 '1 HR' 4 '2-4 HRS' 5 '5+ HRS' 
             8 'DK' 9 'REFUSE' /
   Q70       1 'ASKED BY SOMEONE' 2 'FAM MEMB IN ORG' 3 'THROUGH ORG' 
             4 'SAW AD' 5 'ON OWN' 6 'VOLUNTEER CENTER' 7 'OTHER' 8 'DK' 
             9 'REFUSE' /
   Q71       1 'TOO BUSY' 2 'UNABLE TO HONOR' 3 'NOT INTERESTED' 
             4 'DONT KNOW HOW' 5 'NO ONE ASKED' 6 'WOULDNT MAKE DIFF' 
             7 'OTHER' 8 'DK' 9 'REFUSE' /
   Q72       1 'ENJOY WORK' 2 'FEEL NEEDED' 3 'IMPORTANT TO HELP' 
             4 'FAM IN ACTIVITY' 5 'LEARN NEW SKILLS' 6 'MAKE CONTACTS' 
             7 'OTHER' 8 'DK' 9 'REFUSE' /
   Q73       1 'BIG DIFF' 2 'SOME DIFF' 3 'SMALL DIFF' 4 'NO DIFF' 8 'DK' 
             9 'REFUSE' /
   Q74       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q75       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q76       1 'NOTHING' 2 '$1-$100' 3 '$101-$250' 4 '$251-$500' 
             5 '$501-$999' 6 '$1000+' 9 'DK, REFUSE' /
   Q77       1 '18-34' 2 '35-54' 3 '55+' 9 'REFUSE' /
   Q78       1 '< H.S.' 2 'H.S. GRAD' 3 'SOME COLLEGE' 4 'COLLEGE GRAD' 
             5 'POST GRAD' 9 'REFUSE' /
   Q79       0 'NONE' 1 'ONE' 2 'TWO' 3 'THREE OR MORE' 9 'REFUSE' /
   Q80       1 'NORTH' 2 'WEST' 3 'CENTRAL' 4 'SOUTH' 5 'OUTSIDE OC' 
             9 'NO ANS' /
   Q81       1 'UNDER $36,000' 2 '$36,000-$50,000' 3 '$50,001-$79,999' 
             4 '$80,000+' 9 'DK, REFUSE' /
   Q82       1 'VERY LIBERAL' 2 'SOMEWHAT LIBERAL' 3 'MIDDLE OF ROAD' 
             4 'SOMEWHAT CONSERV' 5 'VERY CONSERV' 9 'REFUSE' /
   Q83       1 'DEMOCRAT' 2 'REPUBLICAN' 3 'INDEP/OTHER' 4 'NOT REGISTERED' 
             9 'REFUSE' /
   Q84       1 'WILSON' 2 'BROWN' 3 'OTHER' 8 'DK' 9 'REFUSE' /
   Q85       1 'HUFFINGTON' 2 'FEINSTEIN' 3 'OTHER' 8 'DK' 9 'REFUSE' /
   Q86       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q87       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q88       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q89       1 'STRONGLY AGREE' 2 'SOMEWHAT AGREE' 3 'SOMEWHAT DISAGREE' 
             4 'STRONGLY DISAGREE' 8 'DK' 9 'REFUSE' /
   Q90       1 'STRONGLY AGREE' 2 'SOMEWHAT AGREE' 3 'SOMEWHAT DISAGREE' 
             4 'STRONGLY DISAGREE' 8 'DK' 9 'REFUSE' /
   Q91       1 'STRONGLY AGREE' 2 'SOMEWHAT AGREE' 3 'SOMEWHAT DISAGREE' 
             4 'STRONGLY DISAGREE' 8 'DK' 9 'REFUSE' /
   Q92       0 'NEVER' 1 '1X' 2 '2X' 3 '3X' 4 '4X+' 8 'DK' 9 'REFUSE' /
   Q93       1 'ASIAN' 2 'BLACK' 3 'HISPANIC' 4 'CAUCASIAN' 5 'OTHER' 
             9 'REFUSE' /
   Q94       1 'MALE' 2 'FEMALE' /
   LANG      1 'ENGLISH' 2 'SPANISH' /
   YEAR      1994 'YEAR OF SURVEY' /
   .

COMMENT  md, min and max specifications were translated into the
COMMENT following "MISSING VALUES" commands and "IF" statements:.

MISSING VALUES  Q1 (9).
MISSING VALUES  Q2 (9).
MISSING VALUES  Q3 (9).
MISSING VALUES  Q4 (9).
MISSING VALUES  Q5 (9).
MISSING VALUES  Q6 (9).
MISSING VALUES  Q7 (9).
MISSING VALUES  Q8 (9).
MISSING VALUES  Q9 (9).
MISSING VALUES  Q10 (9).
MISSING VALUES  Q11 (9).
MISSING VALUES  Q12 (9).
MISSING VALUES  Q13 (9).
MISSING VALUES  Q14 (9).
MISSING VALUES  Q15 (9).
MISSING VALUES  Q16 (9).
MISSING VALUES  Q17 (9).
MISSING VALUES  Q18 (9).
MISSING VALUES  Q19 (9).
MISSING VALUES  Q20 (9).
MISSING VALUES  Q21 (9).
MISSING VALUES  Q22 (9).
MISSING VALUES  Q23 (9).
MISSING VALUES  Q24 (9).
MISSING VALUES  Q25 (9).
MISSING VALUES  Q26 (9).
MISSING VALUES  Q27 (9).
MISSING VALUES  Q28 (9).
MISSING VALUES  Q29 (9).
MISSING VALUES  Q30 (9).
MISSING VALUES  Q31 (9).
MISSING VALUES  Q32 (9).
MISSING VALUES  Q33 (9).
MISSING VALUES  Q34 (9).
MISSING VALUES  Q35 (9).
MISSING VALUES  Q36 (9).
MISSING VALUES  Q37 (9).
MISSING VALUES  Q38 (9).
MISSING VALUES  Q39 (9).
MISSING VALUES  Q40 (9).
MISSING VALUES  Q41 (9).
MISSING VALUES  Q42 (9).
MISSING VALUES  Q43 (9).
MISSING VALUES  Q44 (9).
MISSING VALUES  Q45 (9).
MISSING VALUES  Q46 (9).
MISSING VALUES  Q47 (9).
MISSING VALUES  Q48 (9).
MISSING VALUES  Q49 (9).
MISSING VALUES  Q50 (9).
MISSING VALUES  Q51 (9).
MISSING VALUES  Q52 (9).
MISSING VALUES  Q53 (9).
MISSING VALUES  Q54 (9).
MISSING VALUES  Q55 (9).
MISSING VALUES  Q56 (9).
MISSING VALUES  Q57 (9).
MISSING VALUES  Q58 (9).
MISSING VALUES  Q59 (9).
MISSING VALUES  Q60 (9).
MISSING VALUES  Q61 (9).
MISSING VALUES  Q62 (9).
MISSING VALUES  Q63 (9).
MISSING VALUES  Q64 (9).
MISSING VALUES  Q65 (9).
MISSING VALUES  Q66 (9).
MISSING VALUES  Q67 (9).
MISSING VALUES  Q68 (9).
MISSING VALUES  Q69 (9).
MISSING VALUES  Q70 (9).
MISSING VALUES  Q71 (9).
MISSING VALUES  Q72 (9).
MISSING VALUES  Q73 (9).
MISSING VALUES  Q74 (9).
MISSING VALUES  Q75 (9).
MISSING VALUES  Q76 (9).
MISSING VALUES  Q77 (9).
MISSING VALUES  Q78 (9).
MISSING VALUES  Q79 (9).
MISSING VALUES  Q81 (9).
MISSING VALUES  Q82 (9).
MISSING VALUES  Q83 (9).
MISSING VALUES  Q84 (9).
MISSING VALUES  Q85 (9).
MISSING VALUES  Q86 (9).
MISSING VALUES  Q87 (9).
MISSING VALUES  Q88 (9).
MISSING VALUES  Q89 (9).
MISSING VALUES  Q90 (9).
MISSING VALUES  Q91 (9).
MISSING VALUES  Q92 (9).
MISSING VALUES  Q93 (9).

SAVE OUTFILE=y  /* Replace 'y' with name(within quotes) to give your 
system file
   /MAP
   /COMPRESSED  /* Delete this line if you want an uncompressed file
   .

