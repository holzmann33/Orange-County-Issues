path        = ocas89/
title       = ORANGE COUNTY ANNUAL SURVEY 1989
records/case= 1
reclen      = 96
*
name        = CASEID
label       = CASE ID
type        = numeric
record      = 1
column      = 1
width       = 4
*
name        = Q1
label       = TYPE OF CURRENT RESIDENCE
type        = numeric
record      = 1
column      = 5
width       = 1
md          = 9
catlabels   = 1 SINGLE FAMILY
              2 ATTACHED
              3 APARTMENT
              4 MOBILE
              5 OTHER
              9 REFUSE
text =
	IS THE PLACE WHERE YOU CURRENTLY LIVE A: (ROTATE LIST)

*
name        = Q2
label       = HOW LONG LIVE IN OC
type        = numeric
record      = 1
column      = 6
width       = 1
md          = 9
catlabels   = 1 0-2 YRS
              2 3-5 YRS
              3 6-10 YRS
              4 11-20 YRS
              5 21+ YRS
              9 REFUSE
text =
	HOW LONG HAVE YOU LIVED IN ORANGE COUNTY?

*
name        = Q3
label       = HOW LONG LIVE AT CURRENT RESIDENCE
type        = numeric
record      = 1
column      = 7
width       = 1
md          = 9
catlabels   = 1 0-2 YRS
              2 3-5 YRS
              3 6-10 YRS
              4 11-20 YRS
              5 21+ YRS
              9 REFUSE
text =
	HOW LONG HAVE YOU LIVED AT YOUR CURRENT RESIDENCE?

*
name        = Q4
label       = OWN/RENT PRESENT RESIDENCE
type        = numeric
record      = 1
column      = 8
width       = 1
md          = 9
catlabels   = 1 OWN
              2 RENT
              9 DK, REFUSE
text =
	DO YOU OWN OR RENT YOUR PRESENT RESIDENCE?

*
name        = Q5
label       = HOPE TO OWN HOME SOMEDAY
type        = numeric
record      = 1
column      = 9
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              9 DK, REFUSE
text =
	DO YOU HOPE TO SOME DAY OWN A HOME?

*
name        = Q6
label       = HOW LIKELY WILL OWN W/IN 3 YRS
type        = numeric
record      = 1
column      = 10
width       = 1
md          = 9
catlabels   = 1 VERY LIKELY
              2 SOMEWHAT LIKELY
              3 NOT LIKELY
              8 DK
              9 NA
text =
	REALISTICALLY, HOW LIKELY IS IT THAT WITHIN THE NEXT THREE YEARS YOU WILL OWN YOUR OWN HOME?

*
name        = Q7
label       = MONTHLY RENTAL PAYMENT
type        = numeric
record      = 1
column      = 11
width       = 1
md          = 9
catlabels   = 1 UNDER $500
              2 $501-$750
              3 $751-$1,000
              4 $1,001-$1,500
              5 $1,501+
              9 NA, REFUSE
text =
	WHAT IS YOUR CURRENT MONTHLY RENTAL PAYMENT?

*
name        = Q8
label       = MONTHLY MORTGAGE PAYMENT
type        = numeric
record      = 1
column      = 12
width       = 1
md          = 9
catlabels   = 1 NOTHING
              2 $1-$500
              3 $501-$750
              4 $751-$1,OOO
              5 $1,001-$1,500
              6 $1,501-$2,000
              7 $2,001+
              9 NA, REFUSE
text =
	WHAT IS YOUR CURRENT MONTHLY MORTGAGE PAYMENT, NOT INCLUDING TAXES AND INSURANCE?

*
name        = Q9
label       = CURRENT INTEREST IN MOVING
type        = numeric
record      = 1
column      = 13
width       = 1
md          = 9
catlabels   = 1 NOT INTERESTED
              2 SOMEWHAT INTERESTED
              3 VERY INTERESTED
              9 DK, REFUSE
text =
	AT PRESENT, HOW INTERESTED ARE YOU IN MOVING TO A DIFFERENT RESIDENCE?

*
name        = Q10
label       = INTERESTED IN LEAVING OC
type        = numeric
record      = 1
column      = 14
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              9 NA, REFUSE
text =
	ARE YOU INTERESTED IN MOVING OUTSIDE ORANGE COUNTY?

*
name        = Q11
label       = WHERE INTERESTED IN MOVING TO
type        = numeric
record      = 1
column      = 15
width       = 1
md          = 9
catlabels   = 1 RIV/S BERN CO
              2 SAN DIEGO CO
              3 LA CO
              4 ELSEWHERE
              9 REFUSE
text =
	WHERE ARE YOU CONSIDERING MOVING TO?

*
name        = Q12
label       = MAIN REASON FOR LEAVING OC
type        = numeric
record      = 1
column      = 16
width       = 1
md          = 9
catlabels   = 1 CONGESTION
              2 QUAL OF LIFE
              3 HOUSING
              4 CAREER/FAM
              5 OTHER
              9 REFUSE
text =
	WHAT IS THE MAIN REASON YOU WANT TO MOVE FROM ORANGE COUNTY?

*
name        = Q13
label       = BETTER OFF/WORSE OFF/SAME LAST YEAR
type        = numeric
record      = 1
column      = 17
width       = 1
md          = 9
catlabels   = 1 BETTER OFF
              2 WORSE OFF
              3 SAME
              9 DK, REFUSE
text =
	WOULD YOU SAY YOU (AND YOUR FAMILY) ARE FINANCIALLY BETTER OFF OR WORSE OFF THAN YOU WERE A YEAR 
	AGO?

*
name        = Q14
label       = BETTER OFF/WORSE OFF/SAME NEXT YEAR
type        = numeric
record      = 1
column      = 18
width       = 1
md          = 9
catlabels   = 1 BETTER OFF
              2 WORSE OFF
              3 SAME
              8 DK
              9 REFUSE
text =
	NOW LOOKING AHEAD, DO YOU THINK THAT A YEAR FROM NOW YOU (AND YOUR FAMILY) WILL BE BETTER OFF, 
	WORSE OFF, OR JUST ABOUT THE SAME AS NOW?

*
name        = Q15
label       = GOOD TIMES/BAD TIMES FINANCIALLY
type        = numeric
record      = 1
column      = 19
width       = 1
md          = 9
catlabels   = 1 GOOD TIMES
              2 BAD TIMES
              8 DK
              9 REFUSE
text =
	TURNING TO BUSINESS CONDITIONS IN THE COUNTY AS A WHOLE, DO YOU THINK THAT DURING THE NEXT 12 
	MONTHS WE WILL HAVE GOOD TIMES FINANCIALLY OR BAD TIMES?

*
name        = Q16
label       = CONT. GOOD TIMES NEXT 5 YEARS
type        = numeric
record      = 1
column      = 20
width       = 1
md          = 9
catlabels   = 1 GOOD TIMES
              2 DEPRESSION
              8 DK
              9 REFUSE
text =
	 LOOKING AHEAD, IN THE COUNTRY AS A WHOLE WILL WE HAVE CONTINUED GOOD TIMES DURING THE NEXT 5 
	YEARS OR WILL WE HAVE PERIODS OF WIDESPREAD UNEMPLOYMENT OR DEPRESSION?

*
name        = Q17
label       = GD/BAD TIME TO BUY MAJ. HSEHOLD ITEMS
type        = numeric
record      = 1
column      = 21
width       = 1
md          = 9
catlabels   = 1 GOOD TIME
              2 BAD TIME
              8 NEITHER, DK
              9 REFUSE
text =
	ABOUT THE BIG THINGS THAT PEOPLE BUY FOR THEIR HOMES, SUCH AS FURNITURE, A REFRIGERATOR, A STOVE, 
	TELEVISION AND THINGS LIKE THAT--GENERALLY SPEAKING, DO YOU THINK NOW IS A GOOD OR A BAD TIME FOR PEOPLE 
	TO BUY MAJOR HOUSEHOLD ITEMS?

*
name        = Q18
label       = QUALITY OF LIFE IN OC
type        = numeric
record      = 1
column      = 22
width       = 1
md          = 9
catlabels   = 1 VERY WELL
              2 SOMEWHAT WELL
              3 SOMEWHAT BADLY
              4 VERY BADLY
              9 DK, REFUSE
text =
	THINKING ABOUT THE QUALITY OF LIFE IN ORANGE COUNTY, HOW DO YOU THINK THINGS ARE GOING?

*
name        = Q19
label       = MOST SERIOUS PUBLIC POLICY PROBLEM
type        = numeric
record      = 1
column      = 23
width       = 1
md          = 9
catlabels   = 1 GROWTH
              2 TRAFFIC
              3 HOUSING
              4 CRIME
              5 SCHOOLS
              6 IMMIGRATION
              7 OTHER
              8 DK
              9 DK, REFUSE
text =
	CONSIDERING ALL THE PUBLIC POLICY ISSUES IN ORANGE COUNTY, WHICH OF THESE DO YOU THINK IS THE 
	MOST SERIOUS PROBLEM? (ROTATE LIST)

*
name        = Q20
label       = MOST SERIOUS SOCIAL PROBLEM
type        = numeric
record      = 1
column      = 24
width       = 1
md          = 9
catlabels   = 1 HEALTH CARE
              2 CHILD CARE
              3 RACE RELATIONS
              4 HOMELESS
              5 DRUG ABUSE
              6 AIDS
              7 OTHER
              8 DK
              9 DK, REFUSE
text =
	AS FOR HEALTH AND SOCIAL ISSUES, WHICH OF THESE DO YOU THINK IS ORANGE COUNTY'S MOST SERIOUS 
	PROBLEM? (ROTATE LIST)

*
name        = Q21
label       = OC IN FUTURE
type        = numeric
record      = 1
column      = 25
width       = 1
md          = 9
catlabels   = 1 BETTER PLACE
              2 WORSE PLACE
              3 NO CHANGE
              9 DK, REFUSE
text =
	IN THE FUTURE, DO YOU THINK ORANGE COUNTY WILL BE:

*
name        = Q22
label       = CURRENT GROWTH REGS IN CITY
type        = numeric
record      = 1
column      = 26
width       = 1
md          = 9
catlabels   = 1 TOO STRICT
              2 ABOUT RIGHT
              3 NOT STRICT ENOUGH
              8 DK
              9 DK, REFUSE
text =
	AS FOR CONTROLLING GROWTH, DO YOU THINK THAT CURRENT GOVERNMENT REGULATIONS IN YOUR CITY OR 
	COMMUNITY ARE:

*
name        = Q23
label       = FEELING ABOUT FREEWAYS IN OC
type        = numeric
record      = 1
column      = 27
width       = 1
md          = 9
catlabels   = 1 SATISFACTORY
              2 MORE LANES ONLY
              3 NEW FREEWAYS
              9 DK, REFUSE
text =
	NOW, I'D LIKE TO ASK SOME QUESTIONS ABOUT THE ORANGE COUNTY TRANSPORTATION SYSTEM. FIRST, WHICH 
	OF THE FOLLOWING BEST DESCRIBES HOW YOU 'EEL ABOUT THE FREEWAYS IN ORANGE COUNTY?

*
name        = Q24
label       = NOTICED TRANSP IMPROVEMENTS PAST YR
type        = numeric
record      = 1
column      = 28
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              9 DK, REFUSE
text =
	CURRENTLY, THERE ARE MANY TRANSPORTATION PROJECTS UNDER WAY IN ORANGE COUNTY. IN THE LAST YEAR, 
	HAVE YOU NOTICED ANY IMPROVEMENTS IN YOUR TRAVEL?

*
name        = Q25
label       = FEEL SAFE IN NEIGHBORHOOD
type        = numeric
record      = 1
column      = 29
width       = 1
md          = 9
catlabels   = 1 VERY SAFE
              2 SOMEWHAT SAFE
              3 SOMEWHAT UNSAFE
              4 VERY UNSAFE
              8 DK
              9 REFUSE
text =
	AS FAR AS YOUR OWN COMMUNITY IS CONCERNED, HOW SAFE DO YOU FEEL WALKING ALONE IN YOUR 
	NEIGHBORHOOD DURING THE DAY? WOULD YOU SAY YOU FEEL.....

*
name        = Q26
label       = FEAR OF CRIME HINDERS ACTIVITIES
type        = numeric
record      = 1
column      = 30
width       = 1
md          = 9
catlabels   = 1 ALWAYS
              2 OFTEN
              3 SOMETIMES
              4 RARELY
              5 NEVER
              8 DK
              9 REFUSE
text=
	HOW OFTEN DOES FEAR OF CRIME PREVENT YOU FROM DOING THINGS YOU WOULD LIKE TO DO?

*
name        = Q27
label       = AIR POLLUTION IN SO CAL
type        = numeric
record      = 1
column      = 31
width       = 1
md          = 9
catlabels   = 1 BIG PROBLEM
              2 SOMEWHAT PROBLEM
              3 SMALL PROBLEM
              4 NO PROBLEM
              8 DK
              9 REFUSE
text =
	ON ANOTHER ISSUE, IN YOUR OPINION HOW MUCH OF A PROBLEM IS AIR POLLUTION IN THE SOUTHERN 
	CALIFORNIA AREA?

*
name        = Q28
label       = AIR POLLUTION IN OC
type        = numeric
record      = 1
column      = 32
width       = 1
md          = 9
catlabels   = 1 BIG PROBLEM
              2 SOMEWHAT PROBLEM
              3 SMALL PROBLEM
              4 NO PROBLEM
              8 DK
              9 REFUSE
text =
	AND IN YOUR OPINION, HOW MUCH OF A PROBLEM IS AIR POLLUTION IN ORANGE COUNTY?

*
name        = Q29
label       = CLEAN AIR AT ANY COST
type        = numeric
record      = 1
column      = 33
width       = 1
md          = 9
catlabels   = 1 AGREE
              2 DISAGREE
              8 DK
              9 REFUSE
text =
	SOME PEOPLE THINK IT IS IMPORTANT TO HAVE CLEAN AIR IN SOUTHERN CALIFORNIA AT ANY COST. DO YOU 
	AGREE OR DISAGREE WITH THIS POINT OF VIEW?

*
name        = Q30
label       = FAMILIAR W/ AQMP
type        = numeric
record      = 1
column      = 34
width       = 1
md          = 9
catlabels   = 1 VERY FAMILIAR
              2 SOMEWHAT FAMILIAR
              3 NOT FAMILIAR
              8 DK
              9 DK, REFUSE
text =
	THE SOUTH COAST AIR QUALITY MANAGEMENT DISTRICT RECENTLY APPROVED A PLAN TO REDUCE AIR POLLUTION. 
	SOME OF THE PROPOSALS PLACE NEW RESTRICTIONS ON BUSINESSES AND INDIVIDUALS. HOW FAMILIAR ARE YOU WITH THE 
	AIR QUALITY MANAGEMENT PLAN?	

*
name        = Q31
label       = FAVOR FOR REGIONAL AIR QUAL AGENCY
type        = numeric
record      = 1
column      = 35
width       = 1
md          = 9
catlabels   = 1 VERY FAVORABLE
              2 SOMEWHAT FAVORABLE
              3 NOT FAVORABLE
              8 DK
              9 REFUSE
text =
	HOW FAVORABLE ARE YOU TOWARDS HAVING A SOUTHERN CALIFORNIA REGIONAL AGENCY RATHER THAN A COUNTY 
	AGENCY RESPONSIBLE FOR IMPROVING AIR QUALITY?

*
name        = Q32
label       = BANNING GAS-POWERED LAMN MOWERS
type        = numeric
record      = 1
column      = 36
width       = 1
md          = 9
catlabels   = 1 STRONGLY FAVOR
              2 SOMEWHAT FAVOR
              3 SOMEWHAT OPPOSE
              4 STRONGLY OPPOSE
              8 DK
              9 REFUSE
text =
	I AM GOING TO READ YOU A LIST OF SOME AIR QUALITY MANAGEMENT PROPOSALS THAT WILL AFFECT 
	INDIVIDUALS. PLEASE TELL ME IF YOU IF YOU STRONGLY FAVOR, SOMEWHAT FAVOR, SOMEWHAT OPPOSE OR STRONGLY 
	OPPOSE EACH ONE. 
	FIRST, BANNING GASOLINE-POWERED LAWN MOWERS.

*
name        = Q33
label       = RESTRICTING BBQ STARTER FLUIDS
type        = numeric
record      = 1
column      = 37
width       = 1
md          = 9
catlabels   = 1 STRONGLY FAVOR
              2 SOMEWHAT FAVOR
              3 SOMEWHAT OPPOSE
              4 STRONGLY OPPOSE
              8 DK
              9 REFUSE
text =
	I AM GOING TO READ YOU A LIST OF SOME AIR QUALITY MANAGEMENT PROPOSALS THAT WILL AFFECT 
	INDIVIDUALS. PLEASE TELL ME IF YOU IF YOU STRONGLY FAVOR, SOMEWHAT FAVOR, SOMEWHAT OPPOSE OR STRONGLY 
	OPPOSE EACH ONE. 
	RESTRICTING THE USE OF PETROLEUM-BASED BARBECUE STARTER FLUIDS.

*
name        = Q34
label       = REQUIRING SOLAR HEATERS
type        = numeric
record      = 1
column      = 38
width       = 1
md          = 9
catlabels   = 1 STRONGLY FAVOR
              2 SOMEWHAT FAVOR
              3 SOMEWHAT OPPOSE
              4 STRONGLY OPPOSE
              8 DK
              9 REFUSE
text =
	I AM GOING TO READ YOU A LIST OF SOME AIR QUALITY MANAGEMENT PROPOSALS THAT WILL AFFECT 
	INDIVIDUALS. PLEASE TELL ME IF YOU IF YOU STRONGLY FAVOR, SOMEWHAT FAVOR, SOMEWHAT OPPOSE OR STRONGLY 
	OPPOSE EACH ONE. 
	REQUIRING NEW HOMES TO HAVE SOLAR-POWERED HEATERS FOR THEIR SWIMMING POOLS AND SPAS.

*
name        = Q35
label       = LIMITING DRIVE-THROUGH LANES
type        = numeric
record      = 1
column      = 39
width       = 1
md          = 9
catlabels   = 1 STRONGLY FAVOR
              2 SOMEWHAT FAVOR
              3 SOMEWHAT OPPOSE
              4 STRONGLY OPPOSE
              8 DK
              9 REFUSE
text =
	I AM GOING TO READ YOU A LIST OF SOME AIR QUALITY MANAGEMENT PROPOSALS THAT WILL AFFECT 
	INDIVIDUALS. PLEASE TELL ME IF YOU IF YOU STRONGLY FAVOR, SOMEWHAT FAVOR, SOMEWHAT OPPOSE OR STRONGLY 
	OPPOSE EACH ONE. 
	LIMITING NEW DRIVE-THROUGH LANES AT BANKS AND FAST FOOD RESTAURANTS.

*
name        = Q36
label       = BANNING AEROSOLS
type        = numeric
record      = 1
column      = 40
width       = 1
md          = 9
catlabels   = 1 STRONGLY FAVOR
              2 SOMEWHAT FAVOR
              3 SOMEWHAT OPPOSE
              4 STRONGLY OPPOSE
              8 DK
              9 REFUSE
text =
	I AM GOING TO READ YOU A LIST OF SOME AIR QUALITY MANAGEMENT PROPOSALS THAT WILL AFFECT 
	INDIVIDUALS. PLEASE TELL ME IF YOU IF YOU STRONGLY FAVOR, SOMEWHAT FAVOR, SOMEWHAT OPPOSE OR STRONGLY 
	OPPOSE EACH ONE.
	BANNING MANY OF THE CURRENT AEROSOL HAIR SPRAYS AND DEODORANTS.
	
*
name        = Q37
label       = PARKING FEES TO ENCOURAGE CARPOOLS
type        = numeric
record      = 1
column      = 41
width       = 1
md          = 9
catlabels   = 1 STRONGLY FAVOR
              2 SOMEWHAT FAVOR
              3 SOMEWHAT OPPOSE
              4 STRONGLY OPPOSE
              8 DK
              9 REFUSE
text =
	THERE ARE ALSO A NUMBER OF PROPOSED AIR QUALITY REGULATIONS THAT WILL AFFECT BUSINESS AND 
	GOVERNMENT. WHAT DO YOU THINK ABOUT GIVING LOCAL GOVERNMENTS THE OPTION OF IMPOSING PARKING 
	CHARGES FOR SINGLE-RIDER COMMUTERS IN ORDER TO ENCOURAGE PEOPLE TO CARPOOL?

*
name        = Q38
label       = RIDE-SHARING INCENTIVES
type        = numeric
record      = 1
column      = 42
width       = 1
md          = 9
catlabels   = 1 STRONGLY FAVOR
              2 SOMEWHAT FAVOR
              3 SOMEWHAT OPPOSE
              4 STRONGLY OPPOSE
              8 DK
              9 REFUSE
text =	
	THERE ARE ALSO A NUMBER OF PROPOSED AIR QUALITY REGULATIONS THAT WILL AFFECT BUSINESS AND 
	GOVERNMENT. WHAT DO YOU THINK ABOUT HAVING LARGER EMPLOYERS INCREASE RIDE-SHARING AND MASS 
	TRANSIT USE BY OFFERING THEIR WORKERS INCENTIVES?

*
name        = Q39
label       = JOBS-HOUSING BALANCE
type        = numeric
record      = 1
column      = 43
width       = 1
md          = 9
catlabels   = 1 STRONGLY FAVOR
              2 SOMEWHAT FAVOR
              3 SOMEWHAT OPPOSE
              4 STRONGLY OPPOSE
              8 DK
              9 REFUSE
text =
	THERE ARE ALSO A NUMBER OF PROPOSED AIR QUALITY REGULATIONS THAT WILL AFFECT BUSINESS AND 
	GOVERNMENT. WHAT DO YOU THINK ABOUT HAVING LOCAL GOVERNMENTS BE REQUIRED BY REGIONAL AGENCIES TO 
	HAVE A "JOBS-HOUSING BALANCE," THAT IS, TO LOCATE NEW HOUSING NEAR EMPLOYMENT CENTERS AND LOCATING NEW 
	JOBS NEAR POPULATION CENTERS TO REDUCE CONGESTION. DO YOU STRONGLY FAVOR, SOMEWHAT FAVOR, SOMEWHAT OPPOSE 
	OR STRONGLY OPPOSE THIS PROPOSAL?
 
* 
name        = Q40
label       = BANNING CFC'S
type        = numeric
record      = 1
column      = 44
width       = 1
md          = 9
catlabels   = 1 STRONGLY FAVOR
              2 SOMEWHAT FAVOR
              3 SOMEWHAT OPPOSE
              4 STRONGLY OPPOSE
              8 DK
              9 REFUSE
text =
	THERE ARE ALSO A NUMBER OF PROPOSED AIR QUALITY REGULATIONS THAT WILL AFFECT BUSINESS AND 
	GOVERNMENT. WHAT DO YOU THINK 	ABOUT BANNING THE COMMERCIAL USES OF CHLORO-FLUORO-CARBONS, WHICH 
	ARE THE CHEMICALS LINKED TO THE HOLE IN THE OZONE LAYER OF THE ATMOSPHERE?

*
name        = Q41
label       = REQUIRING CLEAN FUELS
type        = numeric
record      = 1
column      = 45
width       = 1
md          = 9
catlabels   = 1 STRONGLY FAVOR
              2 SOMEWHAT FAVOR
              3 SOMEWHAT OPPOSE
              4 STRONGLY OPPOSE
              8 DK
              9 REFUSE
text =
	THERE ARE ALSO A NUMBER OF PROPOSED AIR QUALITY REGULATIONS THAT WILL AFFECT BUSINESS AND 
	GOVERNMENT. WHAT DO YOU THINK ABOUT REQUIRING NEW MOTOR VEHICLES, IN THE FUTURE, TO RUN ON 
	METHANOL AND OTHER "CLEAN" FUELS INSTEAD OF GASOLINE?

*
name        = Q42
label       = AQMP EFFECT ON OC ECONOMY
type        = numeric
record      = 1
column      = 46
width       = 1
md          = 9
catlabels   = 1 GOOD EFFECT
              2 BAD EFFECT
              3 NO EFFECT
              8 DK
              9 REFUSE
text =
	WHAT KIND OF EFFECT DO YOU THINK THAT THE PLANS TO IMPROVE AIR QUALITY WILL HAVE ON JOBS AND THE 
	ECONOMY IN ORANGE COUNTY?

*
name        = Q43
label       = AQMP EFFECT ON LIFE IN OC
type        = numeric
record      = 1
column      = 47
width       = 1
md          = 9
catlabels   = 1 GOOD EFFECT
              2 BAD EFFECT
              3 NO EFFECT
              8 DK
              9 REFUSE
text =
	WHAT KIND-OF EFFECT DO YOU THINK THAT THE PLANS TO IMPROVE AIR QUALITY WILL HAVE ON THE QUALITY 
	OF LIFE IN ORANGE COUNTY?

*
name        = Q54
label       = $ GAVE TO ALL CHARITIES LAST YR
type        = numeric
record      = 1
column      = 48
width       = 1
md          = 9
catlabels   = 1 NOTHING
              2 $1-$100
              3 $101-$250
              4 $251-$500
              5 $501-$999
              6 $1,000+
              8 DK
              9 DK, REFUSE
text =
	ON ANOTHER ISSUE, HOW MUCH MONEY DID YOU GIVE TO ALL CHARITIES LAST YEAR?

*
name        = Q55
label       = VOLUNTEER TIME FOR CHARITY
type        = numeric
record      = 1
column      = 49
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              9 DK, REFUSE
text =
	CURRENTLY, DO YOU VOLUNTEER TIME TO ANY CHARITIES ON A REGULAR BASIS OR
	NOT?

*
name        = Q66
label       = WORK STATUS
type        = numeric
record      = 1
column      = 50
width       = 1
md          = 9
catlabels   = 1 FULL-TIME
              2 PART-TIME
              3 NOT EMPLOYED
              9 REFUSE
text =
	WHAT IS YOUR CURRENT WORK STATUS?

*
name        = Q67
label       = WORKPLACE
type        = numeric
record      = 1
column      = 51
width       = 2
md          = 9
catlabels   = 1 NORTH
              2 WEST
              3 CENTRAL
              4 SOUTH
              5 LA COUNTY
              8 OTHER
              9 NA, REFUSE
text =
	WHAT IS THE CITY OR COMMUNITY OF YOUR WORKPLACE?

*
name        = Q68
label       = HOW COMMUTE TO WORK
type        = numeric
record      = 1
column      = 53
width       = 1
md          = 9
catlabels   = 1 DRIVE ALONE
              2 CARPOOL
              3 VANPOOL
              4 PUBLIC TRANSIT
              5 OTHER
              9 DK, REFUSE
text =
	HOW DO YOU USUALLY COMMUTE TO WORK?

*
name        = Q69
label       = TRAFFIC CONGESTION DURING COMMUTE
type        = numeric
record      = 1
column      = 54
width       = 1
md          = 9
catlabels   = 1 NO PROBLEM
              2 SLIGHT PROBLEM
              3 GREAT PROBLEM
              9 DK, REFUSE
text =
	ON A TYPICAL DAY, HOW MUCH OF A PROBLEM IS TRAFFIC CONGESTION WHEN YOU TRAVEL TO AND FROM WORK? WOULD YOU 
	SAY IT IS....

*
name        = Q70
label       = TRAFFIC CONGESTION TREND
type        = numeric
record      = 1
column      = 55
width       = 1
md          = 9
catlabels   = 1 GOTTEN BETTER
              2 GOTTEN WORSE
              3 STAYED SAME
              9 DK, REFUSE
text =
	IN THE TIME YOU HAVE COMMUTED ALONG THIS ROUTE, DO YOU THINK THAT THE PROBLEM OF TRAFFIC 
	CONGESTION HAS.....

*
name        = Q71
label       = AGE
type        = numeric
record      = 1
column      = 56
width       = 1
md          = 9
catlabels   = 1 18-24
              2 25-34
              3 35-44
              4 45-54
              5 55-64
              6 65+
              9 REFUSE
text =
	WHAT IS YOUR AGE?

*
name        = Q72
label       = EDUCATION
type        = numeric
record      = 1
column      = 57
width       = 1
md          = 9
catlabels   = 1 < H.S.
              2 H.S. GRAD
              3 SOME COLLEGE
              4 COLLEGE GRAD
              5 POST GRAD
              9 REFUSE
text =
	WHAT WAS THE LAST GRADE OF SCHOOL THAT YOU COMPLETED?

*
name        = Q73
label       = NUMBER OF PERSONS IN HOUSEHOLD
type        = numeric
record      = 1
column      = 58
width       = 1
md          = 9
catlabels   = 1 1
              2 2
              3 3
              4 4
              5 5
              6 6
              7 7
              8 8+
              9 REFUSE
text =
	HOW MANY PERSONS, INCLUDING YOURSELF, LIVE IN YOUR HOUSEHOLD? 

*
name        = Q74
label       = NUMBER OF FT WORKERS IN HHOLD
type        = numeric
record      = 1
column      = 59
width       = 1
md          = 9
catlabels   = 1 1
              2 2
              3 3
              4 4
              5 5
              6 6
              7 7
              8 8+
              9 NONE, REFUSE
text =
	HOW MANY ADULT FULL-TIME WORKERS, INCLUDING YOURSELF, LIVE IN YOUR HOUSEHOLD?

*
name        = Q75
label       = RESIDENCE
type        = numeric
record      = 1
column      = 60
width       = 2
catlabels   = 1 NORTH
              2 WEST
              3 CENTRAL
              4 SOUTH
text =
	WHAT IS THE CITY OR COMMUNITY OF YOUR CURRENT RESIDENCE?

*
name        = Q76
label       = MARITAL STATUS
type        = numeric
record      = 1
column      = 62
width       = 1
md          = 9
catlabels   = 1 MARRIED
              2 DIVORCED
              3 WIDOWED
              4 SINGLE
              9 REFUSE
text =
	WHAT IS YOUR CURRENT MARITAL STATUS?

*
name        = Q77
label       = EVER BEEN DIVORCED
type        = numeric
record      = 1
column      = 63
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              9 NA, REFUSE
text =
	HAVE YOU EVER BEEN DIVORCED?

*
name        = Q78
label       = CHILDREN IN HOUSEHOLD
type        = numeric
record      = 1
column      = 64
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              9 REFUSE
text =
	ARE THERE CHILDREN, 18 AND UNDER, LIVING IN YOUR HOUSEHOLD?

*
name        = Q79
label       = HOUSEHOLD INCOME
type        = numeric
record      = 1
column      = 65
width       = 1
md          = 9
catlabels   = 1 UNDER $25,000
              2 $25,000-$35,999
              3 $36,000-$50,000
              4 $50,001-$65,999
              5 $66,000-$79,999
              6 $80,000-$110,000
              7 $110,000+
              9 REFUSE
text =
	WHICH OF THE FOLLOWING CATEGORIES BEST DESCRIBES YOUR TOTAL HOUSEHOLD INCOME BEFORE TAXES, FROM 
	ALL SOURCES?

*
name        = Q80
label       = PARTY
type        = numeric
record      = 1
column      = 66
width       = 1
md          = 9
catlabels   = 1 DEMOCRAT
              2 REPUBLICAN
              3 INDEP/OTHER
              4 NOT REG
              9 REFUSE
text =
	IF YOU ARE CURRENTLY REGISTERED TO VOTE, ARE YOU REGISTERED AS A DEMOCRAT OR A REPUBLICAN?

*
name        = Q81
label       = VOTE ON PROPERTY TAX INITIATIVE
type        = numeric
record      = 1
column      = 67
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
text =
	IF A VOTE WERE HELD TODAY, WOULD YOU VOTE YES OR NO ON A STATEWIDE INITIATIVE THAT WOULD DOUBLE 
	THE TAX RATE FOR BUSINESS PROPERTY AND j	DECREASE PROPERTY TAXES BY 500 DOLLARS FOR HOMEOWNERS AND 
	RENTERS?
 
*
name        = Q82
label       = VOTE ON GASOLINE TAX INCREASE
type        = numeric
record      = 1
column      = 68
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              8 DK
              9 REFUSE
text =
	IF A VOTE WERE HELD TODAY, WOULD YOU VOTE YES OR NO ON A STATEWIDE MEASURE WHICH WOULD INCREASE 
	THE SPENDING LIMIT FOR ALL STATE PROGRAMS, THUS ALLOWING A NINE CENT PER GALLON INCREASE IN THE GASOLINE 
	TAX TO PAY FOR TRANSPORTATION PROJECTS?

*
name        = Q83
label       = VOTE FOR GOVERNOR
type        = numeric
record      = 1
column      = 69
width       = 1
md          = 9
catlabels   = 1 WILSON
              2 VAN DE KAMP
              8 DK
              9 REFUSE
text =
	IF YOU WERE VOTING FOR GOVERNOR TODAY, WOULD YOU VOTE FOR... (ROTATE)

*
name        = Q84
label       = CONSIDER YOURSELF POLITICALLY:
type        = numeric
record      = 1
column      = 70
width       = 1
md          = 9
catlabels   = 1 VERY LIBERAL
              2 SOMEWHAT LIBERAL
              3 MIDDLE OF ROAD
              4 SOMEWHAT CONSERV
              5 VERY CONSERV
              8 DK
              9 REFUSE
text =
	WOULD YOU CONSIDER YOURSELF TO BE POLITICALLY:

*
name        = Q85
label       = OC POLITICAL CLIMATE
type        = numeric
record      = 1
column      = 71
width       = 1
md          = 9
catlabels   = 1 VERY LIBERAL
              2 SOMEWHAT LIBERAL
              3 MIDDLE OF ROAD
              4 SOMEWHAT CONSERV
              5 VERY CONSERV
              8 DK
              9 REFUSE
text =
	HOW WOULD YOU DESCRIBE THE OVERALL POLITICAL CLIMATE IN ORANGE COUNTY?

*
name        = Q86
label       = OC PARTY PROFILE
type        = numeric
record      = 1
column      = 72
width       = 1
md          = 9
catlabels   = 1 DEMOCRAT
              2 REPUBLICAN
              3 DIVIDED
              8 DK
              9 REFUSE
text =
	AND HOW WOULD YOU DESCRIBE THE OVERALL PARTY PROFILE OF ORANGE COUNTY--ARE MOST PEOPLE DEMOCRATS 
	OR REPUBLICANS?

*
name        = Q87
label       = ATTITUDES OF PEOPLE YOU KNOW
type        = numeric
record      = 1
column      = 73
width       = 1
md          = 9
catlabels   = 1 VERY LIBERAL
              2 SOMEWHAT LIBERAL
              3 MIDDLE OF ROAD
              4 SOMEWHAT CONSERV
              5 VERY CONSERV
              8 DK
              9 REFUSE
text =
	HOW WOULD YOU DESCRIBE THE POLITICAL ATTITUDES OF MOST OF THE PEOPLE YOU SOCIALIZE AND WORK WITH?

*
name        = Q88
label       = PARTY OF PEOPLE YOU KNOW
type        = numeric
record      = 1
column      = 74
width       = 1
md          = 9
catlabels   = 1 DEMOCRAT
              2 REPUBLICAN
              3 DIVIDED
              8 DK
              9 REFUSE
text =
	AND HOW WOULD YOU DESCRIBE THE PARTY PROFILE OF MOST OF THE PEOPLE YOU SOCIALIZE AND WORK WITH-- 
	ARE THEY DEMOCRATS OR REPUBLICANS?

*
name        = Q89
label       = WILLING TO BE REINTERVIEWED
type        = numeric
record      = 1
column      = 75
width       = 1
md          = 9
catlabels   = 1 YES
              2 NO
              9 NA, REFUSE
text =
	WOULD YOU BE WILLING TO BE CONTACTED FOR A FOLLOW-UP DISCUSSION OF '.THESE ISSUES AT A LATER 
	DATE?

*
name        = Q90
label       = SEX
type        = numeric
record      = 1
column      = 76
width       = 1
catlabels   = 1 MALE
              2 FEMALE
*
name        = WEIGHT
label       = WEIGHT
type        = numeric
record      = 1
column      = 77
width       = 8
decimals    = 2
*
name        = WT
label       = WT
type        = numeric
record      = 1
column      = 85
width       = 8
decimals    = 2
*
name        = YEAR
label       = YEAR OF SURVEY
type        = numeric
record      = 1
column      = 93
width       = 4
catlabels   = 1989 YEAR OF SURVERY
