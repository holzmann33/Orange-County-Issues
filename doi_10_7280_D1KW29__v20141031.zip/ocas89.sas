 /*  SAS Data Definition File                        */
 /*  Created by ddltox on Mar 28, 2002  (Thu 03:29 PM PST)  */
 /*  DDL source file: "/u/d7/big/sda_1.2a/tmpdir/AA.paWcs.txt".  */

/* DDL indicates that dataset record length (reclen) is 96 columns. */

TITLE "ORANGE COUNTY ANNUAL SURVEY";
FILENAME INDATA "    ";      /* Put name of data file between quotes */
LIBNAME LIBRARY "    ";    /* Put directory of data library between quotes */

PROC  FORMAT LIB=LIBRARY;
  VALUE Q1f       1='SINGLE FAMILY' 2='ATTACHED' 3='APARTMENT' 4='MOBILE' 
                  5='OTHER' 9='REFUSE' ;
  VALUE Q2f       1='0-2 YRS' 2='3-5 YRS' 3='6-10 YRS' 4='11-20 YRS' 
                  5='21+ YRS' 9='REFUSE' ;
  VALUE Q3f       1='0-2 YRS' 2='3-5 YRS' 3='6-10 YRS' 4='11-20 YRS' 
                  5='21+ YRS' 9='REFUSE' ;
  VALUE Q4f       1='OWN' 2='RENT' 9='DK, REFUSE' ;
  VALUE Q5f       1='YES' 2='NO' 9='DK, REFUSE' ;
  VALUE Q6f       1='VERY LIKELY' 2='SOMEWHAT LIKELY' 3='NOT LIKELY' 8='DK' 
                  9='NA' ;
  VALUE Q7f       1='UNDER $500' 2='$501-$750' 3='$751-$1,000' 
                  4='$1,001-$1,500' 5='$1,501+' 9='NA, REFUSE' ;
  VALUE Q8f       1='NOTHING' 2='$1-$500' 3='$501-$750' 4='$751-$1,OOO' 
                  5='$1,001-$1,500' 6='$1,501-$2,000' 7='$2,001+' 
                  9='NA, REFUSE' ;
  VALUE Q9f       1='NOT INTERESTED' 2='SOMEWHAT INTERESTED' 
                  3='VERY INTERESTED' 9='DK, REFUSE' ;
  VALUE Q10f      1='YES' 2='NO' 9='NA, REFUSE' ;
  VALUE Q11f      1='RIV/S BERN CO' 2='SAN DIEGO CO' 3='LA CO' 4='ELSEWHERE' 
                  9='REFUSE' ;
  VALUE Q12f      1='CONGESTION' 2='QUAL OF LIFE' 3='HOUSING' 4='CAREER/FAM' 
                  5='OTHER' 9='REFUSE' ;
  VALUE Q13f      1='BETTER OFF' 2='WORSE OFF' 3='SAME' 9='DK, REFUSE' ;
  VALUE Q14f      1='BETTER OFF' 2='WORSE OFF' 3='SAME' 8='DK' 9='REFUSE' ;
  VALUE Q15f      1='GOOD TIMES' 2='BAD TIMES' 8='DK' 9='REFUSE' ;
  VALUE Q16f      1='GOOD TIMES' 2='DEPRESSION' 8='DK' 9='REFUSE' ;
  VALUE Q17f      1='GOOD TIME' 2='BAD TIME' 8='NEITHER, DK' 9='REFUSE' ;
  VALUE Q18f      1='VERY WELL' 2='SOMEWHAT WELL' 3='SOMEWHAT BADLY' 
                  4='VERY BADLY' 9='DK, REFUSE' ;
  VALUE Q19f      1='GROWTH' 2='TRAFFIC' 3='HOUSING' 4='CRIME' 5='SCHOOLS' 
                  6='IMMIGRATION' 7='OTHER' 8='DK' 9='DK, REFUSE' ;
  VALUE Q20f      1='HEALTH CARE' 2='CHILD CARE' 3='RACE RELATIONS' 
                  4='HOMELESS' 5='DRUG ABUSE' 6='AIDS' 7='OTHER' 8='DK' 
                  9='DK, REFUSE' ;
  VALUE Q21f      1='BETTER PLACE' 2='WORSE PLACE' 3='NO CHANGE' 
                  9='DK, REFUSE' ;
  VALUE Q22f      1='TOO STRICT' 2='ABOUT RIGHT' 3='NOT STRICT ENOUGH' 8='DK' 
                  9='DK, REFUSE' ;
  VALUE Q23f      1='SATISFACTORY' 2='MORE LANES ONLY' 3='NEW FREEWAYS' 
                  9='DK, REFUSE' ;
  VALUE Q24f      1='YES' 2='NO' 9='DK, REFUSE' ;
  VALUE Q25f      1='VERY SAFE' 2='SOMEWHAT SAFE' 3='SOMEWHAT UNSAFE' 
                  4='VERY UNSAFE' 8='DK' 9='REFUSE' ;
  VALUE Q26f      1='ALWAYS' 2='OFTEN' 3='SOMETIMES' 4='RARELY' 5='NEVER' 
                  8='DK' 9='REFUSE' ;
  VALUE Q27f      1='BIG PROBLEM' 2='SOMEWHAT PROBLEM' 3='SMALL PROBLEM' 
                  4='NO PROBLEM' 8='DK' 9='REFUSE' ;
  VALUE Q28f      1='BIG PROBLEM' 2='SOMEWHAT PROBLEM' 3='SMALL PROBLEM' 
                  4='NO PROBLEM' 8='DK' 9='REFUSE' ;
  VALUE Q29f      1='AGREE' 2='DISAGREE' 8='DK' 9='REFUSE' ;
  VALUE Q30f      1='VERY FAMILIAR' 2='SOMEWHAT FAMILIAR' 3='NOT FAMILIAR' 
                  8='DK' 9='DK, REFUSE' ;
  VALUE Q31f      1='VERY FAVORABLE' 2='SOMEWHAT FAVORABLE' 3='NOT FAVORABLE' 
                  8='DK' 9='REFUSE' ;
  VALUE Q32f      1='STRONGLY FAVOR' 2='SOMEWHAT FAVOR' 3='SOMEWHAT OPPOSE' 
                  4='STRONGLY OPPOSE' 8='DK' 9='REFUSE' ;
  VALUE Q33f      1='STRONGLY FAVOR' 2='SOMEWHAT FAVOR' 3='SOMEWHAT OPPOSE' 
                  4='STRONGLY OPPOSE' 8='DK' 9='REFUSE' ;
  VALUE Q34f      1='STRONGLY FAVOR' 2='SOMEWHAT FAVOR' 3='SOMEWHAT OPPOSE' 
                  4='STRONGLY OPPOSE' 8='DK' 9='REFUSE' ;
  VALUE Q35f      1='STRONGLY FAVOR' 2='SOMEWHAT FAVOR' 3='SOMEWHAT OPPOSE' 
                  4='STRONGLY OPPOSE' 8='DK' 9='REFUSE' ;
  VALUE Q36f      1='STRONGLY FAVOR' 2='SOMEWHAT FAVOR' 3='SOMEWHAT OPPOSE' 
                  4='STRONGLY OPPOSE' 8='DK' 9='REFUSE' ;
  VALUE Q37f      1='STRONGLY FAVOR' 2='SOMEWHAT FAVOR' 3='SOMEWHAT OPPOSE' 
                  4='STRONGLY OPPOSE' 8='DK' 9='REFUSE' ;
  VALUE Q38f      1='STRONGLY FAVOR' 2='SOMEWHAT FAVOR' 3='SOMEWHAT OPPOSE' 
                  4='STRONGLY OPPOSE' 8='DK' 9='REFUSE' ;
  VALUE Q39f      1='STRONGLY FAVOR' 2='SOMEWHAT FAVOR' 3='SOMEWHAT OPPOSE' 
                  4='STRONGLY OPPOSE' 8='DK' 9='REFUSE' ;
  VALUE Q40f      1='STRONGLY FAVOR' 2='SOMEWHAT FAVOR' 3='SOMEWHAT OPPOSE' 
                  4='STRONGLY OPPOSE' 8='DK' 9='REFUSE' ;
  VALUE Q41f      1='STRONGLY FAVOR' 2='SOMEWHAT FAVOR' 3='SOMEWHAT OPPOSE' 
                  4='STRONGLY OPPOSE' 8='DK' 9='REFUSE' ;
  VALUE Q42f      1='GOOD EFFECT' 2='BAD EFFECT' 3='NO EFFECT' 8='DK' 
                  9='REFUSE' ;
  VALUE Q43f      1='GOOD EFFECT' 2='BAD EFFECT' 3='NO EFFECT' 8='DK' 
                  9='REFUSE' ;
  VALUE Q54f      1='NOTHING' 2='$1-$100' 3='$101-$250' 4='$251-$500' 
                  5='$501-$999' 6='$1,000+' 8='DK' 9='DK, REFUSE' ;
  VALUE Q55f      1='YES' 2='NO' 9='DK, REFUSE' ;
  VALUE Q66f      1='FULL-TIME' 2='PART-TIME' 3='NOT EMPLOYED' 9='REFUSE' ;
  VALUE Q67f      1='NORTH' 2='WEST' 3='CENTRAL' 4='SOUTH' 5='LA COUNTY' 
                  8='OTHER' 9='NA, REFUSE' ;
  VALUE Q68f      1='DRIVE ALONE' 2='CARPOOL' 3='VANPOOL' 4='PUBLIC TRANSIT' 
                  5='OTHER' 9='DK, REFUSE' ;
  VALUE Q69f      1='NO PROBLEM' 2='SLIGHT PROBLEM' 3='GREAT PROBLEM' 
                  9='DK, REFUSE' ;
  VALUE Q70f      1='GOTTEN BETTER' 2='GOTTEN WORSE' 3='STAYED SAME' 
                  9='DK, REFUSE' ;
  VALUE Q71f      1='18-24' 2='25-34' 3='35-44' 4='45-54' 5='55-64' 6='65+' 
                  9='REFUSE' ;
  VALUE Q72f      1='< H.S.' 2='H.S. GRAD' 3='SOME COLLEGE' 4='COLLEGE GRAD' 
                  5='POST GRAD' 9='REFUSE' ;
  VALUE Q73f      1='1' 2='2' 3='3' 4='4' 5='5' 6='6' 7='7' 8='8+' 9='REFUSE' ;
  VALUE Q74f      1='1' 2='2' 3='3' 4='4' 5='5' 6='6' 7='7' 8='8+' 
                  9='NONE, REFUSE' ;
  VALUE Q75f      1='NORTH' 2='WEST' 3='CENTRAL' 4='SOUTH' ;
  VALUE Q76f      1='MARRIED' 2='DIVORCED' 3='WIDOWED' 4='SINGLE' 9='REFUSE' ;
  VALUE Q77f      1='YES' 2='NO' 9='NA, REFUSE' ;
  VALUE Q78f      1='YES' 2='NO' 9='REFUSE' ;
  VALUE Q79f      1='UNDER $25,000' 2='$25,000-$35,999' 3='$36,000-$50,000' 
                  4='$50,001-$65,999' 5='$66,000-$79,999' 
                  6='$80,000-$110,000' 7='$110,000+' 9='REFUSE' ;
  VALUE Q80f      1='DEMOCRAT' 2='REPUBLICAN' 3='INDEP/OTHER' 4='NOT REG' 
                  9='REFUSE' ;
  VALUE Q81f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q82f      1='YES' 2='NO' 8='DK' 9='REFUSE' ;
  VALUE Q83f      1='WILSON' 2='VAN DE KAMP' 8='DK' 9='REFUSE' ;
  VALUE Q84f      1='VERY LIBERAL' 2='SOMEWHAT LIBERAL' 3='MIDDLE OF ROAD' 
                  4='SOMEWHAT CONSERV' 5='VERY CONSERV' 8='DK' 9='REFUSE' ;
  VALUE Q85f      1='VERY LIBERAL' 2='SOMEWHAT LIBERAL' 3='MIDDLE OF ROAD' 
                  4='SOMEWHAT CONSERV' 5='VERY CONSERV' 8='DK' 9='REFUSE' ;
  VALUE Q86f      1='DEMOCRAT' 2='REPUBLICAN' 3='DIVIDED' 8='DK' 9='REFUSE' ;
  VALUE Q87f      1='VERY LIBERAL' 2='SOMEWHAT LIBERAL' 3='MIDDLE OF ROAD' 
                  4='SOMEWHAT CONSERV' 5='VERY CONSERV' 8='DK' 9='REFUSE' ;
  VALUE Q88f      1='DEMOCRAT' 2='REPUBLICAN' 3='DIVIDED' 8='DK' 9='REFUSE' ;
  VALUE Q89f      1='YES' 2='NO' 9='NA, REFUSE' ;
  VALUE Q90f      1='MALE' 2='FEMALE' ;
  VALUE YEAR      1989='YEAR OF SURVERY' ;
RUN;

DATA IN (LABEL="ORANGE COUNTY ANNUAL SURVEY");
  INFILE INDATA LRECL=96;
  INPUT
    #1  CASEID 1-4              Q1 5                    Q2 6                    
        Q3 7                    Q4 8                    Q5 9                    
        Q6 10                   Q7 11                   Q8 12                   
        Q9 13                   Q10 14                  Q11 15                  
        Q12 16                  Q13 17                  Q14 18                  
        Q15 19                  Q16 20                  Q17 21                  
        Q18 22                  Q19 23                  Q20 24                  
        Q21 25                  Q22 26                  Q23 27                  
        Q24 28                  Q25 29                  Q26 30                  
        Q27 31                  Q28 32                  Q29 33                  
        Q30 34                  Q31 35                  Q32 36                  
        Q33 37                  Q34 38                  Q35 39                  
        Q36 40                  Q37 41                  Q38 42                  
        Q39 43                  Q40 44                  Q41 45                  
        Q42 46                  Q43 47                  Q54 48                  
        Q55 49                  Q66 50                  Q67 51-52               
        Q68 53                  Q69 54                  Q70 55                  
        Q71 56                  Q72 57                  Q73 58                  
        Q74 59                  Q75 60-61               Q76 62                  
        Q77 63                  Q78 64                  Q79 65                  
        Q80 66                  Q81 67                  Q82 68                  
        Q83 69                  Q84 70                  Q85 71                  
        Q86 72                  Q87 73                  Q88 74                  
        Q89 75                  Q90 76                  WEIGHT 77-84 .2         
        WT 85-92 .2             YEAR 93-96              ;

  LABEL
   CASEID  = 'CASE ID'
   Q1      = 'TYPE OF CURRENT RESIDENCE'
   Q2      = 'HOW LONG LIVE IN OC'
   Q3      = 'HOW LONG LIVE AT CURRENT RESIDENCE'
   Q4      = 'OWN/RENT PRESENT RESIDENCE'
   Q5      = 'HOPE TO OWN HOME SOMEDAY'
   Q6      = 'HOW LIKELY WILL OWN W/IN 3 YRS'
   Q7      = 'MONTHLY RENTAL PAYMENT'
   Q8      = 'MONTHLY MORTGAGE PAYMENT'
   Q9      = 'CURRENT INTEREST IN MOVING'
   Q10     = 'INTERESTED IN LEAVING OC'
   Q11     = 'WHERE INTERESTED IN MOVING TO'
   Q12     = 'MAIN REASON FOR LEAVING OC'
   Q13     = 'BETTER OFF/WORSE OFF/SAME LAST YEAR'
   Q14     = 'BETTER OFF/WORSE OFF/SAME NEXT YEAR'
   Q15     = 'GOOD TIMES/BAD TIMES FINANCIALLY'
   Q16     = 'CONT. GOOD TIMES NEXT 5 YEARS'
   Q17     = 'GD/BAD TIME TO BUY MAJ. HSEHOLD ITEMS'
   Q18     = 'QUALITY OF LIFE IN OC'
   Q19     = 'MOST SERIOUS PUBLIC POLICY PROBLEM'
   Q20     = 'MOST SERIOUS SOCIAL PROBLEM'
   Q21     = 'OC IN FUTURE'
   Q22     = 'CURRENT GROWTH REGS IN CITY'
   Q23     = 'FEELING ABOUT FREEWAYS IN OC'
   Q24     = 'NOTICED TRANSP IMPROVEMENTS PAST YR'
   Q25     = 'FEEL SAFE IN NEIGHBORHOOD'
   Q26     = 'FEAR OF CRIME HINDERS ACTIVITIES'
   Q27     = 'AIR POLLUTION IN SO CAL'
   Q28     = 'AIR POLLUTION IN OC'
   Q29     = 'CLEAN AIR AT ANY COST'
   Q30     = 'FAMILIAR W/ AQMP'
   Q31     = 'FAVOR FOR REGIONAL AIR QUAL AGENCY'
   Q32     = 'BANNING GAS-POWERED LAMN MOWERS'
   Q33     = 'RESTRICTING BBQ STARTER FLUIDS'
   Q34     = 'REQUIRING SOLAR HEATERS'
   Q35     = 'LIMITING DRIVE-THROUGH LANES'
   Q36     = 'BANNING AEROSOLS'
   Q37     = 'PARKING FEES TO ENCOURAGE CARPOOLS'
   Q38     = 'RIDE-SHARING INCENTIVES'
   Q39     = 'JOBS-HOUSING BALANCE'
   Q40     = 'BANNING CFC''S'
   Q41     = 'REQUIRING CLEAN FUELS'
   Q42     = 'AQMP EFFECT ON OC ECONOMY'
   Q43     = 'AQMP EFFECT ON LIFE IN OC'
   Q54     = '$ GAVE TO ALL CHARITIES LAST YR'
   Q55     = 'VOLUNTEER TIME FOR CHARITY'
   Q66     = 'WORK STATUS'
   Q67     = 'WORKPLACE'
   Q68     = 'HOW COMMUTE TO WORK'
   Q69     = 'TRAFFIC CONGESTION DURING COMMUTE'
   Q70     = 'TRAFFIC CONGESTION TREND'
   Q71     = 'AGE'
   Q72     = 'EDUCATION'
   Q73     = 'NUMBER OF PERSONS IN HOUSEHOLD'
   Q74     = 'NUMBER OF FT WORKERS IN HHOLD'
   Q75     = 'RESIDENCE'
   Q76     = 'MARITAL STATUS'
   Q77     = 'EVER BEEN DIVORCED'
   Q78     = 'CHILDREN IN HOUSEHOLD'
   Q79     = 'HOUSEHOLD INCOME'
   Q80     = 'PARTY'
   Q81     = 'VOTE ON PROPERTY TAX INITIATIVE'
   Q82     = 'VOTE ON GASOLINE TAX INCREASE'
   Q83     = 'VOTE FOR GOVERNOR'
   Q84     = 'CONSIDER YOURSELF POLITICALLY:'
   Q85     = 'OC POLITICAL CLIMATE'
   Q86     = 'OC PARTY PROFILE'
   Q87     = 'ATTITUDES OF PEOPLE YOU KNOW'
   Q88     = 'PARTY OF PEOPLE YOU KNOW'
   Q89     = 'WILLING TO BE REINTERVIEWED'
   Q90     = 'SEX'
   WEIGHT  = 'WEIGHT'
   WT      = 'WT'
   YEAR    = 'YEAR OF SURVEY'  ;
  FORMAT Q1 Q1f. Q2 Q2f. Q3 Q3f. 
         Q4 Q4f. Q5 Q5f. Q6 Q6f. 
         Q7 Q7f. Q8 Q8f. Q9 Q9f. 
         Q10 Q10f. Q11 Q11f. Q12 Q12f. 
         Q13 Q13f. Q14 Q14f. Q15 Q15f. 
         Q16 Q16f. Q17 Q17f. Q18 Q18f. 
         Q19 Q19f. Q20 Q20f. Q21 Q21f. 
         Q22 Q22f. Q23 Q23f. Q24 Q24f. 
         Q25 Q25f. Q26 Q26f. Q27 Q27f. 
         Q28 Q28f. Q29 Q29f. Q30 Q30f. 
         Q31 Q31f. Q32 Q32f. Q33 Q33f. 
         Q34 Q34f. Q35 Q35f. Q36 Q36f. 
         Q37 Q37f. Q38 Q38f. Q39 Q39f. 
         Q40 Q40f. Q41 Q41f. Q42 Q42f. 
         Q43 Q43f. Q54 Q54f. Q55 Q55f. 
         Q66 Q66f. Q67 Q67f. Q68 Q68f. 
         Q69 Q69f. Q70 Q70f. Q71 Q71f. 
         Q72 Q72f. Q73 Q73f. Q74 Q74f. 
         Q75 Q75f. Q76 Q76f. Q77 Q77f. 
         Q78 Q78f. Q79 Q79f. Q80 Q80f. 
         Q81 Q81f. Q82 Q82f. Q83 Q83f. 
         Q84 Q84f. Q85 Q85f. Q86 Q86f. 
         Q87 Q87f. Q88 Q88f. Q89 Q89f. 
         Q90 Q90f. YEAR YEAR.  ;

/* md, min and max specifications were translated  */
/* into the following "IF" statements:           */

IF (Q1 = 9) THEN Q1 = .;
IF (Q2 = 9) THEN Q2 = .;
IF (Q3 = 9) THEN Q3 = .;
IF (Q4 = 9) THEN Q4 = .;
IF (Q5 = 9) THEN Q5 = .;
IF (Q6 = 9) THEN Q6 = .;
IF (Q7 = 9) THEN Q7 = .;
IF (Q8 = 9) THEN Q8 = .;
IF (Q9 = 9) THEN Q9 = .;
IF (Q10 = 9) THEN Q10 = .;
IF (Q11 = 9) THEN Q11 = .;
IF (Q12 = 9) THEN Q12 = .;
IF (Q13 = 9) THEN Q13 = .;
IF (Q14 = 9) THEN Q14 = .;
IF (Q15 = 9) THEN Q15 = .;
IF (Q16 = 9) THEN Q16 = .;
IF (Q17 = 9) THEN Q17 = .;
IF (Q18 = 9) THEN Q18 = .;
IF (Q19 = 9) THEN Q19 = .;
IF (Q20 = 9) THEN Q20 = .;
IF (Q21 = 9) THEN Q21 = .;
IF (Q22 = 9) THEN Q22 = .;
IF (Q23 = 9) THEN Q23 = .;
IF (Q24 = 9) THEN Q24 = .;
IF (Q25 = 9) THEN Q25 = .;
IF (Q26 = 9) THEN Q26 = .;
IF (Q27 = 9) THEN Q27 = .;
IF (Q28 = 9) THEN Q28 = .;
IF (Q29 = 9) THEN Q29 = .;
IF (Q30 = 9) THEN Q30 = .;
IF (Q31 = 9) THEN Q31 = .;
IF (Q32 = 9) THEN Q32 = .;
IF (Q33 = 9) THEN Q33 = .;
IF (Q34 = 9) THEN Q34 = .;
IF (Q35 = 9) THEN Q35 = .;
IF (Q36 = 9) THEN Q36 = .;
IF (Q37 = 9) THEN Q37 = .;
IF (Q38 = 9) THEN Q38 = .;
IF (Q39 = 9) THEN Q39 = .;
IF (Q40 = 9) THEN Q40 = .;
IF (Q41 = 9) THEN Q41 = .;
IF (Q42 = 9) THEN Q42 = .;
IF (Q43 = 9) THEN Q43 = .;
IF (Q54 = 9) THEN Q54 = .;
IF (Q55 = 9) THEN Q55 = .;
IF (Q66 = 9) THEN Q66 = .;
IF (Q67 = 9) THEN Q67 = .;
IF (Q68 = 9) THEN Q68 = .;
IF (Q69 = 9) THEN Q69 = .;
IF (Q70 = 9) THEN Q70 = .;
IF (Q71 = 9) THEN Q71 = .;
IF (Q72 = 9) THEN Q72 = .;
IF (Q73 = 9) THEN Q73 = .;
IF (Q74 = 9) THEN Q74 = .;
IF (Q76 = 9) THEN Q76 = .;
IF (Q77 = 9) THEN Q77 = .;
IF (Q78 = 9) THEN Q78 = .;
IF (Q79 = 9) THEN Q79 = .;
IF (Q80 = 9) THEN Q80 = .;
IF (Q81 = 9) THEN Q81 = .;
IF (Q82 = 9) THEN Q82 = .;
IF (Q83 = 9) THEN Q83 = .;
IF (Q84 = 9) THEN Q84 = .;
IF (Q85 = 9) THEN Q85 = .;
IF (Q86 = 9) THEN Q86 = .;
IF (Q87 = 9) THEN Q87 = .;
IF (Q88 = 9) THEN Q88 = .;
IF (Q89 = 9) THEN Q89 = .;

PROC DATASETS;
  CONTENTS DATA=IN POSITION;
  TITLE 'CONTENTS OF ALL VARIABLES';
RUN;
