 /*  SPSS Data Definition File
 /*  Created by ddltox on Jan 13, 2003  (Mon 03:52 PM PST)
 /*  DDL source file: "/u/d7/big/sda_1.2a/tmpdir/AAg4aaVF.txt".

TITLE "ORANGE COUNTY SURVEYS".
COMMENT  DDL indicates that dataset record length (reclen) is 96 columns.

DATA LIST fixed records=1
  FILE=x  /* Replace 'x' with name(within quotes) of your input data file
 /1           CASEID 1-4                    Q1 5                    Q2 6
                    Q3 7                    Q4 8                    Q5 9
                   Q6 10                   Q7 11                   Q8 12
                   Q9 13                  Q10 14                  Q11 15
                  Q12 16                  Q13 17                  Q14 18
                  Q15 19                  Q16 20                  Q17 21
                  Q18 22                  Q19 23                  Q20 24
                  Q21 25                  Q22 26                  Q23 27
                  Q24 28                  Q25 29                  Q26 30
                  Q27 31                  Q28 32                  Q29 33
                  Q30 34                  Q31 35                  Q32 36
                  Q33 37                  Q34 38                  Q35 39
                  Q36 40                  Q37 41                  Q38 42
                  Q39 43                  Q40 44                  Q41 45
                  Q42 46                  Q43 47                  Q54 48
                  Q55 49                  Q66 50               Q67 51-52
                  Q68 53                  Q69 54                  Q70 55
                  Q71 56                  Q72 57                  Q73 58
                  Q74 59               Q75 60-61                  Q76 62
                  Q77 63                  Q78 64                  Q79 65
                  Q80 66                  Q81 67                  Q82 68
                  Q83 69                  Q84 70                  Q85 71
                  Q86 72                  Q87 73                  Q88 74
                  Q89 75                  Q90 76        WEIGHT 77-84 (2)
            WT 85-92 (2)              YEAR 93-96
   .

VARIABLE LABELS
   CASEID    'CASE ID' /
   Q1        'TYPE OF CURRENT RESIDENCE' /
   Q2        'HOW LONG LIVE IN OC' /
   Q3        'HOW LONG LIVE AT CURRENT RESIDENCE' /
   Q4        'OWN/RENT PRESENT RESIDENCE' /
   Q5        'HOPE TO OWN HOME SOMEDAY' /
   Q6        'HOW LIKELY WILL OWN W/IN 3 YRS' /
   Q7        'MONTHLY RENTAL PAYMENT' /
   Q8        'MONTHLY MORTGAGE PAYMENT' /
   Q9        'CURRENT INTEREST IN MOVING' /
   Q10       'INTERESTED IN LEAVING OC' /
   Q11       'WHERE INTERESTED IN MOVING TO' /
   Q12       'MAIN REASON FOR LEAVING OC' /
   Q13       'BETTER OFF/WORSE OFF/SAME LAST YEAR' /
   Q14       'BETTER OFF/WORSE OFF/SAME NEXT YEAR' /
   Q15       'GOOD TIMES/BAD TIMES FINANCIALLY' /
   Q16       'CONT. GOOD TIMES NEXT 5 YEARS' /
   Q17       'GD/BAD TIME TO BUY MAJ. HSEHOLD ITEMS' /
   Q18       'QUALITY OF LIFE IN OC' /
   Q19       'MOST SERIOUS PUBLIC POLICY PROBLEM' /
   Q20       'MOST SERIOUS SOCIAL PROBLEM' /
   Q21       'OC IN FUTURE' /
   Q22       'CURRENT GROWTH REGS IN CITY' /
   Q23       'FEELING ABOUT FREEWAYS IN OC' /
   Q24       'NOTICED TRANSP IMPROVEMENTS PAST YR' /
   Q25       'FEEL SAFE IN NEIGHBORHOOD' /
   Q26       'FEAR OF CRIME HINDERS ACTIVITIES' /
   Q27       'AIR POLLUTION IN SO CAL' /
   Q28       'AIR POLLUTION IN OC' /
   Q29       'CLEAN AIR AT ANY COST' /
   Q30       'FAMILIAR W/ AQMP' /
   Q31       'FAVOR FOR REGIONAL AIR QUAL AGENCY' /
   Q32       'BANNING GAS-POWERED LAMN MOWERS' /
   Q33       'RESTRICTING BBQ STARTER FLUIDS' /
   Q34       'REQUIRING SOLAR HEATERS' /
   Q35       'LIMITING DRIVE-THROUGH LANES' /
   Q36       'BANNING AEROSOLS' /
   Q37       'PARKING FEES TO ENCOURAGE CARPOOLS' /
   Q38       'RIDE-SHARING INCENTIVES' /
   Q39       'JOBS-HOUSING BALANCE' /
   Q40       'BANNING CFC''S' /
   Q41       'REQUIRING CLEAN FUELS' /
   Q42       'AQMP EFFECT ON OC ECONOMY' /
   Q43       'AQMP EFFECT ON LIFE IN OC' /
   Q54       '$ GAVE TO ALL CHARITIES LAST YR' /
   Q55       'VOLUNTEER TIME FOR CHARITY' /
   Q66       'WORK STATUS' /
   Q67       'WORKPLACE' /
   Q68       'HOW COMMUTE TO WORK' /
   Q69       'TRAFFIC CONGESTION DURING COMMUTE' /
   Q70       'TRAFFIC CONGESTION TREND' /
   Q71       'AGE' /
   Q72       'EDUCATION' /
   Q73       'NUMBER OF PERSONS IN HOUSEHOLD' /
   Q74       'NUMBER OF FT WORKERS IN HHOLD' /
   Q75       'RESIDENCE' /
   Q76       'MARITAL STATUS' /
   Q77       'EVER BEEN DIVORCED' /
   Q78       'CHILDREN IN HOUSEHOLD' /
   Q79       'HOUSEHOLD INCOME' /
   Q80       'PARTY' /
   Q81       'VOTE ON PROPERTY TAX INITIATIVE' /
   Q82       'VOTE ON GASOLINE TAX INCREASE' /
   Q83       'VOTE FOR GOVERNOR' /
   Q84       'CONSIDER YOURSELF POLITICALLY:' /
   Q85       'OC POLITICAL CLIMATE' /
   Q86       'OC PARTY PROFILE' /
   Q87       'ATTITUDES OF PEOPLE YOU KNOW' /
   Q88       'PARTY OF PEOPLE YOU KNOW' /
   Q89       'WILLING TO BE REINTERVIEWED' /
   Q90       'SEX' /
   WEIGHT    'WEIGHT' /
   WT        'WT' /
   YEAR      'YEAR OF SURVEY' /
   .

VALUE LABELS
   Q1        1 'SINGLE FAMILY' 2 'ATTACHED' 3 'APARTMENT' 4 'MOBILE' 
             5 'OTHER' 9 'REFUSE' /
   Q2        1 '0-2 YRS' 2 '3-5 YRS' 3 '6-10 YRS' 4 '11-20 YRS' 5 '21+ YRS' 
             9 'REFUSE' /
   Q3        1 '0-2 YRS' 2 '3-5 YRS' 3 '6-10 YRS' 4 '11-20 YRS' 5 '21+ YRS' 
             9 'REFUSE' /
   Q4        1 'OWN' 2 'RENT' 9 'DK, REFUSE' /
   Q5        1 'YES' 2 'NO' 9 'DK, REFUSE' /
   Q6        1 'VERY LIKELY' 2 'SOMEWHAT LIKELY' 3 'NOT LIKELY' 8 'DK' 9 'NA' /
   Q7        1 'UNDER $500' 2 '$501-$750' 3 '$751-$1,000' 4 '$1,001-$1,500' 
             5 '$1,501+' 9 'NA, REFUSE' /
   Q8        1 'NOTHING' 2 '$1-$500' 3 '$501-$750' 4 '$751-$1,OOO' 
             5 '$1,001-$1,500' 6 '$1,501-$2,000' 7 '$2,001+' 9 'NA, REFUSE' /
   Q9        1 'NOT INTERESTED' 2 'SOMEWHAT INTERESTED' 3 'VERY INTERESTED' 
             9 'DK, REFUSE' /
   Q10       1 'YES' 2 'NO' 9 'NA, REFUSE' /
   Q11       1 'RIV/S BERN CO' 2 'SAN DIEGO CO' 3 'LA CO' 4 'ELSEWHERE' 
             9 'REFUSE' /
   Q12       1 'CONGESTION' 2 'QUAL OF LIFE' 3 'HOUSING' 4 'CAREER/FAM' 
             5 'OTHER' 9 'REFUSE' /
   Q13       1 'BETTER OFF' 2 'WORSE OFF' 3 'SAME' 9 'DK, REFUSE' /
   Q14       1 'BETTER OFF' 2 'WORSE OFF' 3 'SAME' 8 'DK' 9 'REFUSE' /
   Q15       1 'GOOD TIMES' 2 'BAD TIMES' 8 'DK' 9 'REFUSE' /
   Q16       1 'GOOD TIMES' 2 'DEPRESSION' 8 'DK' 9 'REFUSE' /
   Q17       1 'GOOD TIME' 2 'BAD TIME' 8 'NEITHER, DK' 9 'REFUSE' /
   Q18       1 'VERY WELL' 2 'SOMEWHAT WELL' 3 'SOMEWHAT BADLY' 
             4 'VERY BADLY' 9 'DK, REFUSE' /
   Q19       1 'GROWTH' 2 'TRAFFIC' 3 'HOUSING' 4 'CRIME' 5 'SCHOOLS' 
             6 'IMMIGRATION' 7 'OTHER' 8 'DK' 9 'DK, REFUSE' /
   Q20       1 'HEALTH CARE' 2 'CHILD CARE' 3 'RACE RELATIONS' 4 'HOMELESS' 
             5 'DRUG ABUSE' 6 'AIDS' 7 'OTHER' 8 'DK' 9 'DK, REFUSE' /
   Q21       1 'BETTER PLACE' 2 'WORSE PLACE' 3 'NO CHANGE' 9 'DK, REFUSE' /
   Q22       1 'TOO STRICT' 2 'ABOUT RIGHT' 3 'NOT STRICT ENOUGH' 8 'DK' 
             9 'DK, REFUSE' /
   Q23       1 'SATISFACTORY' 2 'MORE LANES ONLY' 3 'NEW FREEWAYS' 
             9 'DK, REFUSE' /
   Q24       1 'YES' 2 'NO' 9 'DK, REFUSE' /
   Q25       1 'VERY SAFE' 2 'SOMEWHAT SAFE' 3 'SOMEWHAT UNSAFE' 
             4 'VERY UNSAFE' 8 'DK' 9 'REFUSE' /
   Q26       1 'ALWAYS' 2 'OFTEN' 3 'SOMETIMES' 4 'RARELY' 5 'NEVER' 8 'DK' 
             9 'REFUSE' /
   Q27       1 'BIG PROBLEM' 2 'SOMEWHAT PROBLEM' 3 'SMALL PROBLEM' 
             4 'NO PROBLEM' 8 'DK' 9 'REFUSE' /
   Q28       1 'BIG PROBLEM' 2 'SOMEWHAT PROBLEM' 3 'SMALL PROBLEM' 
             4 'NO PROBLEM' 8 'DK' 9 'REFUSE' /
   Q29       1 'AGREE' 2 'DISAGREE' 8 'DK' 9 'REFUSE' /
   Q30       1 'VERY FAMILIAR' 2 'SOMEWHAT FAMILIAR' 3 'NOT FAMILIAR' 8 'DK' 
             9 'DK, REFUSE' /
   Q31       1 'VERY FAVORABLE' 2 'SOMEWHAT FAVORABLE' 3 'NOT FAVORABLE' 
             8 'DK' 9 'REFUSE' /
   Q32       1 'STRONGLY FAVOR' 2 'SOMEWHAT FAVOR' 3 'SOMEWHAT OPPOSE' 
             4 'STRONGLY OPPOSE' 8 'DK' 9 'REFUSE' /
   Q33       1 'STRONGLY FAVOR' 2 'SOMEWHAT FAVOR' 3 'SOMEWHAT OPPOSE' 
             4 'STRONGLY OPPOSE' 8 'DK' 9 'REFUSE' /
   Q34       1 'STRONGLY FAVOR' 2 'SOMEWHAT FAVOR' 3 'SOMEWHAT OPPOSE' 
             4 'STRONGLY OPPOSE' 8 'DK' 9 'REFUSE' /
   Q35       1 'STRONGLY FAVOR' 2 'SOMEWHAT FAVOR' 3 'SOMEWHAT OPPOSE' 
             4 'STRONGLY OPPOSE' 8 'DK' 9 'REFUSE' /
   Q36       1 'STRONGLY FAVOR' 2 'SOMEWHAT FAVOR' 3 'SOMEWHAT OPPOSE' 
             4 'STRONGLY OPPOSE' 8 'DK' 9 'REFUSE' /
   Q37       1 'STRONGLY FAVOR' 2 'SOMEWHAT FAVOR' 3 'SOMEWHAT OPPOSE' 
             4 'STRONGLY OPPOSE' 8 'DK' 9 'REFUSE' /
   Q38       1 'STRONGLY FAVOR' 2 'SOMEWHAT FAVOR' 3 'SOMEWHAT OPPOSE' 
             4 'STRONGLY OPPOSE' 8 'DK' 9 'REFUSE' /
   Q39       1 'STRONGLY FAVOR' 2 'SOMEWHAT FAVOR' 3 'SOMEWHAT OPPOSE' 
             4 'STRONGLY OPPOSE' 8 'DK' 9 'REFUSE' /
   Q40       1 'STRONGLY FAVOR' 2 'SOMEWHAT FAVOR' 3 'SOMEWHAT OPPOSE' 
             4 'STRONGLY OPPOSE' 8 'DK' 9 'REFUSE' /
   Q41       1 'STRONGLY FAVOR' 2 'SOMEWHAT FAVOR' 3 'SOMEWHAT OPPOSE' 
             4 'STRONGLY OPPOSE' 8 'DK' 9 'REFUSE' /
   Q42       1 'GOOD EFFECT' 2 'BAD EFFECT' 3 'NO EFFECT' 8 'DK' 9 'REFUSE' /
   Q43       1 'GOOD EFFECT' 2 'BAD EFFECT' 3 'NO EFFECT' 8 'DK' 9 'REFUSE' /
   Q54       1 'NOTHING' 2 '$1-$100' 3 '$101-$250' 4 '$251-$500' 
             5 '$501-$999' 6 '$1,000+' 8 'DK' 9 'DK, REFUSE' /
   Q55       1 'YES' 2 'NO' 9 'DK, REFUSE' /
   Q66       1 'FULL-TIME' 2 'PART-TIME' 3 'NOT EMPLOYED' 9 'REFUSE' /
   Q67       1 'NORTH' 2 'WEST' 3 'CENTRAL' 4 'SOUTH' 5 'LA COUNTY' 8 'OTHER' 
             9 'NA, REFUSE' /
   Q68       1 'DRIVE ALONE' 2 'CARPOOL' 3 'VANPOOL' 4 'PUBLIC TRANSIT' 
             5 'OTHER' 9 'DK, REFUSE' /
   Q69       1 'NO PROBLEM' 2 'SLIGHT PROBLEM' 3 'GREAT PROBLEM' 
             9 'DK, REFUSE' /
   Q70       1 'GOTTEN BETTER' 2 'GOTTEN WORSE' 3 'STAYED SAME' 
             9 'DK, REFUSE' /
   Q71       1 '18-24' 2 '25-34' 3 '35-44' 4 '45-54' 5 '55-64' 6 '65+' 
             9 'REFUSE' /
   Q72       1 '< H.S.' 2 'H.S. GRAD' 3 'SOME COLLEGE' 4 'COLLEGE GRAD' 
             5 'POST GRAD' 9 'REFUSE' /
   Q73       1 '1' 2 '2' 3 '3' 4 '4' 5 '5' 6 '6' 7 '7' 8 '8+' 9 'REFUSE' /
   Q74       1 '1' 2 '2' 3 '3' 4 '4' 5 '5' 6 '6' 7 '7' 8 '8+' 
             9 'NONE, REFUSE' /
   Q75       1 'NORTH' 2 'WEST' 3 'CENTRAL' 4 'SOUTH' /
   Q76       1 'MARRIED' 2 'DIVORCED' 3 'WIDOWED' 4 'SINGLE' 9 'REFUSE' /
   Q77       1 'YES' 2 'NO' 9 'NA, REFUSE' /
   Q78       1 'YES' 2 'NO' 9 'REFUSE' /
   Q79       1 'UNDER $25,000' 2 '$25,000-$35,999' 3 '$36,000-$50,000' 
             4 '$50,001-$65,999' 5 '$66,000-$79,999' 6 '$80,000-$110,000' 
             7 '$110,000+' 9 'REFUSE' /
   Q80       1 'DEMOCRAT' 2 'REPUBLICAN' 3 'INDEP/OTHER' 4 'NOT REG' 
             9 'REFUSE' /
   Q81       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q82       1 'YES' 2 'NO' 8 'DK' 9 'REFUSE' /
   Q83       1 'WILSON' 2 'VAN DE KAMP' 8 'DK' 9 'REFUSE' /
   Q84       1 'VERY LIBERAL' 2 'SOMEWHAT LIBERAL' 3 'MIDDLE OF ROAD' 
             4 'SOMEWHAT CONSERV' 5 'VERY CONSERV' 8 'DK' 9 'REFUSE' /
   Q85       1 'VERY LIBERAL' 2 'SOMEWHAT LIBERAL' 3 'MIDDLE OF ROAD' 
             4 'SOMEWHAT CONSERV' 5 'VERY CONSERV' 8 'DK' 9 'REFUSE' /
   Q86       1 'DEMOCRAT' 2 'REPUBLICAN' 3 'DIVIDED' 8 'DK' 9 'REFUSE' /
   Q87       1 'VERY LIBERAL' 2 'SOMEWHAT LIBERAL' 3 'MIDDLE OF ROAD' 
             4 'SOMEWHAT CONSERV' 5 'VERY CONSERV' 8 'DK' 9 'REFUSE' /
   Q88       1 'DEMOCRAT' 2 'REPUBLICAN' 3 'DIVIDED' 8 'DK' 9 'REFUSE' /
   Q89       1 'YES' 2 'NO' 9 'NA, REFUSE' /
   Q90       1 'MALE' 2 'FEMALE' /
   YEAR      1989 'YEAR OF SURVERY' /
   .

COMMENT  md, min and max specifications were translated into the
COMMENT following "MISSING VALUES" commands and "IF" statements:.

MISSING VALUES  Q1 (9).
MISSING VALUES  Q2 (9).
MISSING VALUES  Q3 (9).
MISSING VALUES  Q4 (9).
MISSING VALUES  Q5 (9).
MISSING VALUES  Q6 (9).
MISSING VALUES  Q7 (9).
MISSING VALUES  Q8 (9).
MISSING VALUES  Q9 (9).
MISSING VALUES  Q10 (9).
MISSING VALUES  Q11 (9).
MISSING VALUES  Q12 (9).
MISSING VALUES  Q13 (9).
MISSING VALUES  Q14 (9).
MISSING VALUES  Q15 (9).
MISSING VALUES  Q16 (9).
MISSING VALUES  Q17 (9).
MISSING VALUES  Q18 (9).
MISSING VALUES  Q19 (9).
MISSING VALUES  Q20 (9).
MISSING VALUES  Q21 (9).
MISSING VALUES  Q22 (9).
MISSING VALUES  Q23 (9).
MISSING VALUES  Q24 (9).
MISSING VALUES  Q25 (9).
MISSING VALUES  Q26 (9).
MISSING VALUES  Q27 (9).
MISSING VALUES  Q28 (9).
MISSING VALUES  Q29 (9).
MISSING VALUES  Q30 (9).
MISSING VALUES  Q31 (9).
MISSING VALUES  Q32 (9).
MISSING VALUES  Q33 (9).
MISSING VALUES  Q34 (9).
MISSING VALUES  Q35 (9).
MISSING VALUES  Q36 (9).
MISSING VALUES  Q37 (9).
MISSING VALUES  Q38 (9).
MISSING VALUES  Q39 (9).
MISSING VALUES  Q40 (9).
MISSING VALUES  Q41 (9).
MISSING VALUES  Q42 (9).
MISSING VALUES  Q43 (9).
MISSING VALUES  Q54 (9).
MISSING VALUES  Q55 (9).
MISSING VALUES  Q66 (9).
MISSING VALUES  Q67 (9).
MISSING VALUES  Q68 (9).
MISSING VALUES  Q69 (9).
MISSING VALUES  Q70 (9).
MISSING VALUES  Q71 (9).
MISSING VALUES  Q72 (9).
MISSING VALUES  Q73 (9).
MISSING VALUES  Q74 (9).
MISSING VALUES  Q76 (9).
MISSING VALUES  Q77 (9).
MISSING VALUES  Q78 (9).
MISSING VALUES  Q79 (9).
MISSING VALUES  Q80 (9).
MISSING VALUES  Q81 (9).
MISSING VALUES  Q82 (9).
MISSING VALUES  Q83 (9).
MISSING VALUES  Q84 (9).
MISSING VALUES  Q85 (9).
MISSING VALUES  Q86 (9).
MISSING VALUES  Q87 (9).
MISSING VALUES  Q88 (9).
MISSING VALUES  Q89 (9).

SAVE OUTFILE=y  /* Replace 'y' with name(within quotes) to give your 
system file
   /MAP
   /COMPRESSED  /* Delete this line if you want an uncompressed file
   .
